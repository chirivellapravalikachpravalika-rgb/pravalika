# 📊 Power BI Dashboard Design Blueprint
## Marketing Funnel & Conversion Analysis — Olist B2B

---

## Data Model (Star Schema)

```
                    ┌─────────────────────┐
                    │   DIM_Channel        │
                    │  ─────────────────  │
                    │  channel_group (PK) │
                    │  channel_category   │
                    │  is_paid            │
                    └──────────┬──────────┘
                               │
┌───────────────┐    ┌─────────▼──────────┐    ┌───────────────────┐
│  DIM_Segment  │    │   FACT_Funnel       │    │  DIM_Date          │
│ ─────────────│    │  ─────────────────  │    │ ────────────────── │
│ segment (PK)  ├───▶│  mql_id (PK)       │◀───│  date_key (PK)     │
│ category      │    │  channel_group (FK) │    │  year              │
│ is_high_value │    │  first_contact_date │    │  quarter           │
└───────────────┘    │  won_date           │    │  month             │
                     │  converted (0/1)    │    │  week              │
┌───────────────┐    │  days_to_close      │    └───────────────────┘
│  DIM_LeadType │    │  business_segment   │
│ ─────────────│    │  lead_type          │
│ lead_type(PK) ├───▶│  lead_type (FK)     │
│ digital_level │    │  declared_revenue   │
│ is_online     │    │  business_type      │
└───────────────┘    └─────────────────────┘
```

**Import:** Load `clean_master.csv` into Power BI Desktop.

---

## DAX Measures

```dax
-- ── Core Funnel Metrics ─────────────────────────────────────────

Total MQLs = COUNTROWS(FACT_Funnel)

Won Deals = CALCULATE(
    COUNTROWS(FACT_Funnel),
    FACT_Funnel[converted] = 1
)

Conversion Rate = 
DIVIDE([Won Deals], [Total MQLs], 0) * 100

Drop-off Rate = 100 - [Conversion Rate]

Lost Leads = [Total MQLs] - [Won Deals]

-- ── Velocity ────────────────────────────────────────────────────

Avg Days to Close = 
CALCULATE(
    AVERAGE(FACT_Funnel[days_to_close]),
    FACT_Funnel[converted] = 1
)

Median Days to Close = 
CALCULATE(
    MEDIAN(FACT_Funnel[days_to_close]),
    FACT_Funnel[converted] = 1
)

-- ── Revenue ─────────────────────────────────────────────────────

Total Declared Revenue = 
CALCULATE(
    SUM(FACT_Funnel[declared_monthly_revenue]),
    FACT_Funnel[converted] = 1
)

Avg Revenue per Deal = 
DIVIDE([Total Declared Revenue], [Won Deals], 0)

Revenue per MQL = 
DIVIDE([Total Declared Revenue], [Total MQLs], 0)

-- ── Channel Efficiency ──────────────────────────────────────────

Channel Efficiency Ratio = 
DIVIDE(
    DIVIDE([Won Deals], CALCULATE([Won Deals], ALL(FACT_Funnel[channel_group]))),
    DIVIDE([Total MQLs], CALCULATE([Total MQLs], ALL(FACT_Funnel[channel_group]))),
    0
)
-- >1.0 = channel punches above its weight in conversions

-- ── Time Intelligence ────────────────────────────────────────────

MQL MoM Growth = 
VAR CurrentMonth = [Total MQLs]
VAR PriorMonth = CALCULATE(
    [Total MQLs],
    DATEADD(DIM_Date[date_key], -1, MONTH)
)
RETURN DIVIDE(CurrentMonth - PriorMonth, PriorMonth, 0) * 100

Conversion Rate MoM = 
VAR CurrentRate = [Conversion Rate]
VAR PriorRate = CALCULATE(
    [Conversion Rate],
    DATEADD(DIM_Date[date_key], -1, MONTH)
)
RETURN CurrentRate - PriorRate
```

---

## Dashboard Pages

### Page 1 — Executive Summary (KPI Cards)

**Layout:** 2 rows × 4 KPI cards + 1 funnel visual

| Card | Measure | Format | Trend |
|------|---------|--------|-------|
| Total MQLs | `[Total MQLs]` | `#,0` | ↑ MoM |
| Won Deals | `[Won Deals]` | `#,0` | ↑ MoM |
| Conversion Rate | `[Conversion Rate]` | `0.0%` | ↑ MoM |
| Avg Days to Close | `[Avg Days to Close]` | `0 days` | ↓ MoM (good) |
| Total Revenue | `[Total Declared Revenue]` | `$#,0` | ↑ MoM |
| Revenue/Deal | `[Avg Revenue per Deal]` | `$#,0` | ↑ MoM |
| Drop-off Rate | `[Drop-off Rate]` | `0.0%` | ↓ MoM (good) |
| Efficiency Ratio | `[Channel Efficiency Ratio]` | `0.00×` | Context |

**Funnel Visual:** Use the built-in Funnel chart
- Stages: MQL → Qualified* → Engaged* → Won Deal
- Values: 8000, 3200, 1400, 842
- Color: Dark blue → medium blue → light blue → green

**Slicers (top):**
- Date range (first_contact_date)
- Channel Group (multi-select)
- Business Type (reseller / manufacturer)

---

### Page 2 — Channel Analysis

**Top Row:** Clustered bar — MQL Volume by channel (left) + Conversion Rate by channel (right)

**Middle:** Scatter plot (built-in)
- X axis: Total MQLs
- Y axis: Conversion Rate
- Bubble size: Won Deals
- Legend color: channel_group
- Add quadrant reference lines at median values

**Bottom:** Matrix table
| Channel | MQLs | Won | Conv% | Avg Days | Revenue | Efficiency |
|---------|------|-----|-------|----------|---------|------------|

**Conditional Formatting:**
- Conv% → Green (>12%) / Yellow (8–12%) / Red (<8%)
- Efficiency Ratio → Bold if > 1.0

---

### Page 3 — Trend Analysis (Time Series)

**Main Chart:** Line & Clustered Column (combo)
- Columns: Monthly MQL Volume (primary axis, blue)
- Columns: Monthly Won Deals (primary axis, green)
- Line: Monthly Conversion Rate % (secondary axis, red)
- X axis: contact_yearmon (sorted chronologically)

**Secondary:** Area chart — Cumulative MQLs vs Cumulative Deals over time

**Bottom Row:** Three small KPI trend charts (sparklines):
- MQL volume trend (12 months)
- Conversion rate trend (12 months)
- Revenue trend (12 months)

**Slicer:** Quarter selector

---

### Page 4 — Segment Deep Dive

**Left:** Horizontal bar chart — Top 15 segments by Won Deals
- Sort descending by deals
- Color intensity = deal count

**Right:** Treemap — Segment × Business Type
- Size = won deals
- Color = business_type (reseller / manufacturer)

**Bottom:** Matrix heatmap (use conditional formatting on matrix)
- Rows: business_segment (top 12)
- Columns: channel_group
- Values: Won Deals count
- Conditional format: White → Red gradient by value

---

### Page 5 — Lead Quality & Velocity

**Left panel:** Donut — Lead Behaviour Profile breakdown (won deals)
- cat / eagle / wolf / shark / unknown

**Center:** Histogram — Days to Close distribution
- Bins: 0–30, 31–60, 61–90, 91–120, 121–180, 180+
- Color: Green (fast) → Red (slow)

**Right:** Stacked bar — Lead Type by Channel (won deals)
- Shows which channels bring each digital maturity level

**Bottom:** Table sorted by avg_days_close per channel with sparkline trend

---

### Page 6 — Revenue Intelligence

**Top:** Bar chart — Total Declared Revenue by Channel (sorted desc)

**Middle left:** Scatter — Deals Won (X) vs Avg Revenue per Deal (Y)
- Bubble = channel_group
- Reveals which channels bring high-value vs high-volume sellers

**Middle right:** Bar — Revenue by Business Segment (top 10)

**Bottom:** Revenue concentration analysis
- Show cumulative revenue % (Pareto) across segments

---

## Filters & Interactions

Apply cross-filtering across all pages:
- `channel_group` slicer affects all visuals
- `business_type` slicer (reseller / manufacturer) on all pages
- Date range slicer using `first_contact_date`
- All charts cross-filter each other (click a bar to filter)

---

## Color Theme

```
Primary Blue:    #1a237e  (dark navy — headers, main bars)
Secondary Blue:  #5c6bc0  (medium blue — secondary bars)
Light Blue:      #c5cae9  (backgrounds, fills)
Success Green:   #43a047  (converted, good metrics)
Alert Red:       #e53935  (drop-off, bad metrics)
Warning Orange:  #fb8c00  (medium performance)
Background:      #f8f9fa  (page background)
Text:            #212121  (main body text)
Subtitle:        #757575  (secondary text)
```

---

## Deployment Steps

1. **Load data:** File → Get Data → Text/CSV → `data/clean_master.csv`
2. **Create DAX measures** in the Measures table
3. **Build pages** following layout above
4. **Apply theme:** View → Themes → Customize using hex codes above
5. **Publish:** Home → Publish → Select workspace
6. **Schedule refresh:** Set daily refresh in Power BI Service
7. **Share:** Add report to App or share workspace with stakeholders

---

*Power BI Dashboard Guide — Olist B2B Marketing Funnel Analysis*

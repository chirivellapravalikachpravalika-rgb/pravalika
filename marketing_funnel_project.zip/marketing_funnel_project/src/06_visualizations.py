"""
====================================================================
STEP 8 — Visualizations
====================================================================
Marketing Funnel & Conversion Analysis | Olist B2B
====================================================================
Generates 8 publication-quality charts saved to visualizations/
====================================================================
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

MASTER_PATH = "data/clean_master.csv"
VIZ_DIR     = "visualizations/"

# ── Consistent visual style ────────────────────────────────────────
PALETTE     = ["#1a237e", "#283593", "#3949ab", "#5c6bc0",
               "#7986cb", "#9fa8da", "#c5cae9", "#e8eaf6"]
ACCENT      = "#e53935"
GREEN       = "#43a047"
ORANGE      = "#fb8c00"
BG          = "#f8f9fa"

plt.rcParams.update({
    "font.family":    "DejaVu Sans",
    "figure.facecolor": BG,
    "axes.facecolor":   BG,
    "axes.spines.top":  False,
    "axes.spines.right": False,
    "axes.grid":        True,
    "grid.alpha":       0.3,
    "grid.linestyle":   "--",
})


def load_master() -> pd.DataFrame:
    return pd.read_csv(MASTER_PATH, parse_dates=["first_contact_date", "won_date"])


# ─────────────────────────────────────────────────────────────────
# CHART 1 — Funnel Overview
# ─────────────────────────────────────────────────────────────────
def plot_funnel_overview(df: pd.DataFrame) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(14, 7))
    fig.suptitle("Marketing Funnel Overview — Olist B2B",
                 fontsize=16, fontweight="bold", y=1.02)

    # LEFT — Funnel Bar Chart
    ax1 = axes[0]
    stages = ["MQLs\n(Total Leads)", "Sales\nQualified*", "Active\nEngagement*",
              "Deals\nClosed (Won)"]
    # Model intermediate stages as implied proportions
    values = [8000, 3200, 1400, 842]
    colors = ["#1a237e", "#3949ab", "#7986cb", "#43a047"]
    notes  = ["8,000 leads\n(100%)", "~3,200 est.\n(40%)",
               "~1,400 est.\n(17.5%)", "842 won\n(10.5%)"]

    bars = ax1.barh(stages[::-1], values[::-1], color=colors[::-1],
                    height=0.55, edgecolor="white", linewidth=1.5)
    for bar, note in zip(bars, notes[::-1]):
        ax1.text(bar.get_width() + 100, bar.get_y() + bar.get_height() / 2,
                 note, va="center", fontsize=10, color="#333333")

    ax1.set_xlabel("Lead Count", fontsize=11)
    ax1.set_title("Funnel Stage Volumes\n(*estimated from funnel shape)",
                  fontsize=12, fontweight="bold", pad=10)
    ax1.set_xlim(0, 10500)
    ax1.tick_params(axis="y", labelsize=11)

    # RIGHT — Donut chart: converted vs dropped
    ax2 = axes[1]
    converted = df["converted"].sum()
    dropped   = len(df) - converted
    sizes     = [converted, dropped]
    clrs      = [GREEN, ACCENT]
    labels    = [f"Won Deals\n{converted:,} ({converted/len(df)*100:.1f}%)",
                 f"Not Converted\n{dropped:,} ({dropped/len(df)*100:.1f}%)"]

    wedges, texts = ax2.pie(sizes, colors=clrs, startangle=90,
                            wedgeprops=dict(width=0.55, edgecolor="white", linewidth=2))
    ax2.set_title("MQL Conversion Split", fontsize=12, fontweight="bold", pad=15)
    ax2.legend(wedges, labels, loc="lower center", bbox_to_anchor=(0.5, -0.12),
               fontsize=10, frameon=False)

    # Center text
    ax2.text(0, 0, f"10.5%\nConv Rate", ha="center", va="center",
             fontsize=14, fontweight="bold", color="#1a237e")

    plt.tight_layout()
    path = VIZ_DIR + "01_funnel_overview.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   ✅ Saved: {path}")


# ─────────────────────────────────────────────────────────────────
# CHART 2 — Conversion by Channel
# ─────────────────────────────────────────────────────────────────
def plot_conversion_by_channel(df: pd.DataFrame) -> None:
    ch = df.groupby("channel_group").agg(
        mqls=("mql_id", "count"),
        won=("converted", "sum"),
    )
    ch["conv_rate"] = ch["won"] / ch["mqls"] * 100
    ch = ch.sort_values("conv_rate", ascending=True)

    fig, ax = plt.subplots(figsize=(12, 6))
    colors = [GREEN if v > ch["conv_rate"].median() else "#5c6bc0"
              for v in ch["conv_rate"]]
    bars = ax.barh(ch.index, ch["conv_rate"], color=colors,
                   height=0.6, edgecolor="white", linewidth=1.2)

    for bar, (ch_name, row) in zip(bars, ch.iterrows()):
        ax.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height() / 2,
                f"{row['conv_rate']:.1f}%  ({int(row['won'])}/{int(row['mqls'])})",
                va="center", fontsize=10)

    med = ch["conv_rate"].median()
    ax.axvline(med, color=ACCENT, linestyle="--", linewidth=1.5,
               label=f"Median: {med:.1f}%")

    ax.set_xlabel("Conversion Rate (%)", fontsize=11)
    ax.set_title("Conversion Rate by Acquisition Channel",
                 fontsize=14, fontweight="bold", pad=12)
    ax.legend(fontsize=10, frameon=False)
    ax.set_xlim(0, max(ch["conv_rate"]) * 1.4)

    green_patch = mpatches.Patch(color=GREEN,    label="Above Median")
    blue_patch  = mpatches.Patch(color="#5c6bc0", label="Below Median")
    ax.legend(handles=[green_patch, blue_patch,
                        plt.Line2D([0], [0], color=ACCENT, linestyle="--",
                                   label=f"Median {med:.1f}%")],
              fontsize=10, frameon=False, loc="lower right")

    plt.tight_layout()
    path = VIZ_DIR + "02_conversion_by_channel.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   ✅ Saved: {path}")


# ─────────────────────────────────────────────────────────────────
# CHART 3 — Monthly MQL & Deal Trends
# ─────────────────────────────────────────────────────────────────
def plot_monthly_trends(df: pd.DataFrame) -> None:
    monthly_mqls = (
        df.groupby("contact_yearmon")["mql_id"].count().reset_index()
        .rename(columns={"mql_id": "mqls", "contact_yearmon": "month"})
    )
    monthly_won = (
        df[df["converted"] == 1]
        .groupby("won_yearmon")["mql_id"].count().reset_index()
        .rename(columns={"mql_id": "deals", "won_yearmon": "month"})
    )
    merged = monthly_mqls.merge(monthly_won, on="month", how="left").fillna(0)
    merged["conv_rate"] = merged["deals"] / merged["mqls"] * 100

    fig, ax1 = plt.subplots(figsize=(14, 6))
    ax2 = ax1.twinx()

    x = range(len(merged))
    ax1.bar(x, merged["mqls"],   color="#5c6bc0", alpha=0.7,
            label="MQL Volume",   width=0.6)
    ax1.bar(x, merged["deals"],  color=GREEN,     alpha=0.9,
            label="Deals Won",    width=0.4)
    ax2.plot(x, merged["conv_rate"], color=ACCENT, linewidth=2.5,
             marker="o", markersize=5, label="Conv Rate %")

    ax1.set_xticks(list(x))
    ax1.set_xticklabels(merged["month"], rotation=45, ha="right", fontsize=9)
    ax1.set_ylabel("Lead / Deal Count", fontsize=11)
    ax2.set_ylabel("Conversion Rate (%)", fontsize=11, color=ACCENT)
    ax2.tick_params(axis="y", labelcolor=ACCENT)

    fig.suptitle("Monthly MQL Volume, Deals Won & Conversion Rate",
                 fontsize=14, fontweight="bold")

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2,
               loc="upper left", fontsize=10, frameon=False)

    plt.tight_layout()
    path = VIZ_DIR + "03_monthly_trends.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   ✅ Saved: {path}")


# ─────────────────────────────────────────────────────────────────
# CHART 4 — Channel Volume vs Quality (Scatter)
# ─────────────────────────────────────────────────────────────────
def plot_channel_volume_quality(df: pd.DataFrame) -> None:
    ch = df.groupby("channel_group").agg(
        mqls=("mql_id", "count"),
        won=("converted", "sum"),
        revenue=("declared_monthly_revenue", "sum"),
    )
    ch["conv_rate"] = ch["won"] / ch["mqls"] * 100

    fig, ax = plt.subplots(figsize=(11, 7))

    scatter = ax.scatter(
        ch["mqls"], ch["conv_rate"],
        s=ch["won"] * 8, alpha=0.75,
        c=range(len(ch)), cmap="Blues_r",
        edgecolors="#1a237e", linewidth=1.5
    )

    for ch_name, row in ch.iterrows():
        ax.annotate(ch_name,
                    (row["mqls"], row["conv_rate"]),
                    textcoords="offset points",
                    xytext=(8, 4), fontsize=10, fontweight="bold",
                    color="#1a237e")

    # Quadrant lines
    med_x = ch["mqls"].median()
    med_y = ch["conv_rate"].median()
    ax.axvline(med_x, color="#bdbdbd", linestyle="--", linewidth=1.2)
    ax.axhline(med_y, color="#bdbdbd", linestyle="--", linewidth=1.2)

    ax.text(med_x * 1.02, ch["conv_rate"].max() * 0.95, "⭐ SCALE",
            fontsize=10, color=GREEN, fontweight="bold")
    ax.text(50, ch["conv_rate"].max() * 0.95, "🚀 STAR",
            fontsize=10, color="#1a237e", fontweight="bold")
    ax.text(med_x * 1.02, ch["conv_rate"].min() * 1.1, "🔧 FIX",
            fontsize=10, color=ACCENT, fontweight="bold")
    ax.text(50, ch["conv_rate"].min() * 1.1, "🔵 NICHE",
            fontsize=10, color="#757575", fontweight="bold")

    ax.set_xlabel("MQL Volume (Total Leads)", fontsize=12)
    ax.set_ylabel("Conversion Rate (%)", fontsize=12)
    ax.set_title("Channel Volume vs Quality — Strategic Quadrant Map\n"
                 "(Bubble size = Won Deals)", fontsize=13, fontweight="bold")

    plt.tight_layout()
    path = VIZ_DIR + "04_channel_volume_vs_quality.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   ✅ Saved: {path}")


# ─────────────────────────────────────────────────────────────────
# CHART 5 — Business Segment Heatmap
# ─────────────────────────────────────────────────────────────────
def plot_segment_heatmap(df: pd.DataFrame) -> None:
    won = df[df["converted"] == 1]

    # Top 12 segments × channels
    top_segments = (
        won.groupby("business_segment")["mql_id"].count()
        .nlargest(12).index
    )
    top_channels = (
        df.groupby("channel_group")["mql_id"].count()
        .nlargest(7).index
    )

    filtered = won[won["business_segment"].isin(top_segments) &
                    won["channel_group"].isin(top_channels)]

    pivot = filtered.pivot_table(
        index="business_segment",
        columns="channel_group",
        values="mql_id",
        aggfunc="count",
        fill_value=0,
    )

    fig, ax = plt.subplots(figsize=(13, 8))
    sns.heatmap(
        pivot, annot=True, fmt="d", cmap="YlOrRd",
        linewidths=0.5, linecolor="white",
        cbar_kws={"label": "Number of Deals"},
        ax=ax
    )
    ax.set_title("Deal Volume Heatmap — Business Segment × Acquisition Channel",
                 fontsize=13, fontweight="bold", pad=12)
    ax.set_xlabel("Acquisition Channel", fontsize=11)
    ax.set_ylabel("Business Segment",    fontsize=11)
    ax.tick_params(axis="x", rotation=30, labelsize=10)
    ax.tick_params(axis="y", rotation=0,  labelsize=10)

    plt.tight_layout()
    path = VIZ_DIR + "05_business_segment_heatmap.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   ✅ Saved: {path}")


# ─────────────────────────────────────────────────────────────────
# CHART 6 — Lead Type Conversion
# ─────────────────────────────────────────────────────────────────
def plot_lead_type(df: pd.DataFrame) -> None:
    won = df[df["converted"] == 1]
    lt = won["lead_type"].value_counts()

    fig, axes = plt.subplots(1, 2, figsize=(13, 6))

    # Left — Horizontal bars: deal count by lead type
    ax1 = axes[0]
    colors = plt.cm.Blues_r(np.linspace(0.3, 0.9, len(lt)))
    bars = ax1.barh(lt.index[::-1], lt.values[::-1],
                    color=colors, height=0.6,
                    edgecolor="white", linewidth=1.2)
    for bar, val in zip(bars, lt.values[::-1]):
        ax1.text(bar.get_width() + 2, bar.get_y() + bar.get_height() / 2,
                 f"{val} ({val/len(won)*100:.1f}%)", va="center", fontsize=10)
    ax1.set_xlabel("Deals Won", fontsize=11)
    ax1.set_title("Won Deals by Lead Type\n(Digital Maturity of Seller)",
                  fontsize=12, fontweight="bold")
    ax1.set_xlim(0, lt.max() * 1.3)

    # Right — Stacked: lead type distribution across channels
    ax2 = axes[1]
    won_ch = won.groupby(["channel_group", "lead_type"])["mql_id"].count().unstack(fill_value=0)
    won_ch_pct = won_ch.div(won_ch.sum(axis=1), axis=0) * 100

    # Keep top 5 lead types
    top_lt = lt.head(5).index
    won_ch_pct = won_ch_pct[[c for c in top_lt if c in won_ch_pct.columns]]
    won_ch_pct.plot(kind="bar", stacked=True, ax=ax2,
                    colormap="Blues_r", edgecolor="white", linewidth=0.8)
    ax2.set_xlabel("Channel", fontsize=11)
    ax2.set_ylabel("% of Deals (within channel)", fontsize=11)
    ax2.set_title("Lead Type Mix by Channel (Won Deals)",
                  fontsize=12, fontweight="bold")
    ax2.set_xticklabels(ax2.get_xticklabels(), rotation=30, ha="right", fontsize=9)
    ax2.legend(title="Lead Type", bbox_to_anchor=(1, 1), fontsize=9, frameon=False)

    plt.suptitle("Lead Type Analysis — Seller Digital Maturity",
                 fontsize=14, fontweight="bold", y=1.02)
    plt.tight_layout()
    path = VIZ_DIR + "06_lead_type_conversion.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   ✅ Saved: {path}")


# ─────────────────────────────────────────────────────────────────
# CHART 7 — Drop-off Waterfall
# ─────────────────────────────────────────────────────────────────
def plot_dropoff_waterfall(df: pd.DataFrame) -> None:
    """Waterfall chart showing drop at each implied funnel stage."""
    stages   = ["MQL\nCreated", "SDR\nQualified*", "SR\nEngaged*",
                 "Deal\nClosed"]
    values   = [8000, 3200, 1400, 842]
    drops    = [0, 4800, 1800, 558]
    colors   = ["#1a237e", "#e53935", "#e53935", "#43a047"]
    is_total = [True, False, False, True]

    fig, ax = plt.subplots(figsize=(12, 7))

    running = 8000
    bottoms = []
    for i, (stage, val, drop, is_t, col) in enumerate(
            zip(stages, values, drops, is_total, colors)):
        if is_t:
            ax.bar(i, val, color=col, width=0.55,
                   edgecolor="white", linewidth=1.5)
            ax.text(i, val + 100, f"{val:,}", ha="center",
                    fontsize=12, fontweight="bold")
        else:
            # Show remaining + drop
            ax.bar(i, running - drop, color="#5c6bc0",
                   width=0.55, edgecolor="white", linewidth=1.5)
            ax.bar(i, drop, bottom=running - drop, color=ACCENT,
                   width=0.55, alpha=0.7, edgecolor="white")
            ax.text(i, running - drop / 2, f"−{drop:,}\ndrop",
                    ha="center", va="center", fontsize=10,
                    color="white", fontweight="bold")
            running = running - drop

        ax.text(i, -450, stage, ha="center", va="top",
                fontsize=11, fontweight="bold", color="#333333")

    # Conversion labels
    for i, val in enumerate(values):
        pct = val / 8000 * 100
        ax.text(i, val + 350, f"{pct:.1f}%\nof MQL",
                ha="center", fontsize=9, color="#555555")

    ax.set_ylim(-600, 9800)
    ax.set_xlim(-0.6, 3.6)
    ax.set_ylabel("Lead Count", fontsize=11)
    ax.set_title("Funnel Drop-off Waterfall\n"
                 "(*Intermediate stages estimated from funnel shape)",
                 fontsize=14, fontweight="bold", pad=15)
    ax.set_xticks([])

    retained_p = mpatches.Patch(color="#5c6bc0", label="Retained Leads")
    dropped_p  = mpatches.Patch(color=ACCENT,    label="Dropped Leads", alpha=0.7)
    won_p      = mpatches.Patch(color=GREEN,      label="Won Deals")
    mql_p      = mpatches.Patch(color="#1a237e",  label="MQL Total")
    ax.legend(handles=[mql_p, retained_p, dropped_p, won_p],
              loc="upper right", fontsize=10, frameon=False)

    plt.tight_layout()
    path = VIZ_DIR + "07_dropoff_waterfall.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   ✅ Saved: {path}")


# ─────────────────────────────────────────────────────────────────
# CHART 8 — Revenue by Channel
# ─────────────────────────────────────────────────────────────────
def plot_revenue_by_channel(df: pd.DataFrame) -> None:
    won = df[df["converted"] == 1]

    ch_rev = won.groupby("channel_group").agg(
        total_revenue=("declared_monthly_revenue", "sum"),
        avg_revenue=("declared_monthly_revenue", "mean"),
        deals=("mql_id", "count"),
    ).round(0)
    ch_rev = ch_rev.sort_values("total_revenue", ascending=True)

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    # Left — Total revenue bars
    ax1 = axes[0]
    colors = plt.cm.Blues(np.linspace(0.4, 0.9, len(ch_rev)))
    bars = ax1.barh(ch_rev.index, ch_rev["total_revenue"],
                    color=colors, height=0.6, edgecolor="white")
    for bar, val in zip(bars, ch_rev["total_revenue"]):
        ax1.text(bar.get_width() + 500, bar.get_y() + bar.get_height() / 2,
                 f"${val:,.0f}", va="center", fontsize=10)
    ax1.set_xlabel("Declared Monthly Revenue (BRL)", fontsize=11)
    ax1.set_title("Total Revenue Contribution\nby Channel", fontsize=12, fontweight="bold")

    # Right — Avg revenue per deal
    ax2 = axes[1]
    ch_rev_sorted = ch_rev.sort_values("avg_revenue", ascending=True)
    colors2 = [GREEN if v > ch_rev["avg_revenue"].median() else "#5c6bc0"
                for v in ch_rev_sorted["avg_revenue"]]
    bars2 = ax2.barh(ch_rev_sorted.index, ch_rev_sorted["avg_revenue"],
                     color=colors2, height=0.6, edgecolor="white")
    for bar, val in zip(bars2, ch_rev_sorted["avg_revenue"]):
        ax2.text(bar.get_width() + 50, bar.get_y() + bar.get_height() / 2,
                 f"${val:,.0f}", va="center", fontsize=10)
    ax2.set_xlabel("Avg Revenue per Deal (BRL/month)", fontsize=11)
    ax2.set_title("Average Revenue per Won Deal\nby Channel", fontsize=12, fontweight="bold")
    med2 = ch_rev["avg_revenue"].median()
    ax2.axvline(med2, color=ACCENT, linestyle="--", linewidth=1.5,
                label=f"Median: ${med2:,.0f}")
    ax2.legend(fontsize=10, frameon=False)

    plt.suptitle("Revenue Analysis by Acquisition Channel",
                 fontsize=14, fontweight="bold", y=1.02)
    plt.tight_layout()
    path = VIZ_DIR + "08_revenue_by_channel.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   ✅ Saved: {path}")


def main():
    print("\n" + "=" * 60)
    print("  STEP 8: Generating Visualizations")
    print("=" * 60)

    df = load_master()

    print("\n📊 Generating charts...")
    plot_funnel_overview(df)
    plot_conversion_by_channel(df)
    plot_monthly_trends(df)
    plot_channel_volume_quality(df)
    plot_segment_heatmap(df)
    plot_lead_type(df)
    plot_dropoff_waterfall(df)
    plot_revenue_by_channel(df)

    print(f"\n✅ Step 8 Complete — 8 charts saved to {VIZ_DIR}\n")


if __name__ == "__main__":
    main()

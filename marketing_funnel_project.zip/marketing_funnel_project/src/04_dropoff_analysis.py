"""
====================================================================
STEP 6 — Drop-Off Analysis
====================================================================
Marketing Funnel & Conversion Analysis | Olist B2B
====================================================================

DROP-OFF DEFINITION:
---------------------
A "drop-off" occurs when a lead exits the funnel without converting.
Since we have MQL entry and deal close, we measure:

1. OVERALL DROP-OFF : 89.5% of MQLs do not convert
2. CHANNEL DROP-OFF : Which channel loses the most prospects
3. TEMPORAL DROP-OFF: When in time did leads stop converting
4. SEGMENT DROP-OFF : Which business segments fail to convert
5. VELOCITY ANALYSIS: Fast vs slow converters — is speed a signal?

BUSINESS IMPACT:
----------------
Each 1% improvement in conversion rate = ~80 additional sellers.
With average declared revenue of ~$200/month per seller, even a 1%
improvement could represent significant incremental GMV on platform.
====================================================================
"""

import pandas as pd
import numpy as np

MASTER_PATH = "data/clean_master.csv"


def load_master() -> pd.DataFrame:
    df = pd.read_csv(MASTER_PATH, parse_dates=["first_contact_date", "won_date"])
    return df


# ─────────────────────────────────────────────────────────────────
# DROP-OFF ANALYSIS FUNCTIONS
# ─────────────────────────────────────────────────────────────────

def overall_dropoff(df: pd.DataFrame) -> dict:
    """
    Compute the primary funnel drop-off metrics.
    This is the headline number for every funnel conversation.
    """
    total  = len(df)
    won    = df["converted"].sum()
    lost   = total - won

    return {
        "total_mqls":     total,
        "converted":      won,
        "dropped":        lost,
        "drop_rate_pct":  round(lost / total * 100, 2),
        "conv_rate_pct":  round(won  / total * 100, 2),
        "leads_lost_per_100": round(lost / total * 100, 1),
    }


def channel_dropoff(df: pd.DataFrame) -> pd.DataFrame:
    """
    Drop-off broken down by acquisition channel.

    Key insight: High-volume channels are not always the ones
    with the worst drop-off in absolute terms. A channel sending
    1,000 poor leads that convert at 5% loses 950 leads —
    much worse in absolute terms than a small channel at 15%.
    """
    grp = df.groupby("channel_group").agg(
        total=("mql_id", "count"),
        won=("converted", "sum"),
    )
    grp["dropped"]       = grp["total"] - grp["won"]
    grp["drop_rate"]     = (grp["dropped"] / grp["total"] * 100).round(2)
    grp["conv_rate"]     = (grp["won"]     / grp["total"] * 100).round(2)
    grp["abs_drop_rank"] = grp["dropped"].rank(ascending=False).astype(int)
    return grp.sort_values("dropped", ascending=False)


def temporal_dropoff(df: pd.DataFrame) -> pd.DataFrame:
    """
    Month-over-month drop-off trend.

    Watch for:
    - Months where MQL volume spikes but conversions don't follow
      → campaign was driving low-quality leads
    - Months with high conversion rates
      → what was different? (offers, messaging, SDR capacity)
    """
    monthly = (
        df.groupby("contact_yearmon")
        .agg(total=("mql_id", "count"), won=("converted", "sum"))
        .reset_index()
    )
    monthly["dropped"]   = monthly["total"] - monthly["won"]
    monthly["drop_rate"] = (monthly["dropped"] / monthly["total"] * 100).round(2)
    monthly["conv_rate"] = (monthly["won"]     / monthly["total"] * 100).round(2)
    return monthly.sort_values("contact_yearmon")


def velocity_analysis(df: pd.DataFrame) -> dict:
    """
    Analyze sales velocity — does time-to-close predict outcome?

    Hypothesis: Leads that close quickly are higher intent.
    Slow-moving leads are more likely to churn/drop.

    Segment converted deals into fast / medium / slow buckets.
    """
    won = df[df["converted"] == 1].copy()
    won["velocity_bucket"] = pd.cut(
        won["days_to_close"],
        bins=[-1, 30, 90, 180, 999],
        labels=["Fast (<30d)", "Medium (30-90d)", "Slow (90-180d)", "Very Slow (>180d)"]
    )

    velocity_dist = won["velocity_bucket"].value_counts().sort_index()
    velocity_pct  = (velocity_dist / len(won) * 100).round(2)

    return {
        "distribution": velocity_dist,
        "percentage": velocity_pct,
        "avg_days": won["days_to_close"].mean().round(1),
        "median_days": won["days_to_close"].median(),
        "pct_close_within_30": (won["days_to_close"] <= 30).mean() * 100,
        "pct_close_within_90": (won["days_to_close"] <= 90).mean() * 100,
    }


def segment_dropoff(df: pd.DataFrame) -> pd.DataFrame:
    """
    Identify business segments where leads are most frequently lost.

    Since segment is only known for converted deals, we compute
    what % of deals came from each segment, then flag segments
    with low absolute deal counts as potential missed opportunities.
    """
    won = df[df["converted"] == 1]
    seg = (
        won.groupby("business_segment")
        .agg(deals=("mql_id", "count"))
        .sort_values("deals", ascending=False)
    )
    seg["deal_share_pct"] = (seg["deals"] / seg["deals"].sum() * 100).round(2)
    seg["cumulative_pct"] = seg["deal_share_pct"].cumsum().round(2)

    # Flag long-tail segments (below 2% deal share)
    seg["is_long_tail"] = seg["deal_share_pct"] < 2.0
    return seg


def print_dropoff_report(overall, channel_drop, temporal, velocity, segment_drop):
    """Print formatted drop-off analysis report."""
    sep = "=" * 60

    print(f"\n{sep}")
    print("  DROP-OFF ANALYSIS REPORT")
    print(sep)

    print("\n⚠️  OVERALL FUNNEL DROP-OFF")
    print("-" * 40)
    print(f"   Total MQLs entered funnel : {overall['total_mqls']:>6,}")
    print(f"   Deals Won (Converted)      : {overall['converted']:>6,}  "
          f"({overall['conv_rate_pct']}%)")
    print(f"   Leads Dropped / Lost       : {overall['dropped']:>6,}  "
          f"({overall['drop_rate_pct']}%)")
    print(f"   ▶ For every 100 leads, {overall['leads_lost_per_100']:.0f} are LOST")

    print("\n⚠️  CHANNEL DROP-OFF (sorted by absolute lost leads)")
    print("-" * 60)
    print(f"   {'Channel':<18} {'Total':>7} {'Won':>6} {'Dropped':>8} "
          f"{'Drop%':>7} {'Conv%':>7}")
    print("   " + "-" * 55)
    for ch, row in channel_drop.iterrows():
        print(f"   {ch:<18} {row['total']:>7,} {row['won']:>6,} "
              f"{row['dropped']:>8,} {row['drop_rate']:>6.1f}% {row['conv_rate']:>6.1f}%")

    print("\n⚠️  SALES VELOCITY ANALYSIS (Converted Deals Only)")
    print("-" * 40)
    print(f"   Average days to close  : {velocity['avg_days']} days")
    print(f"   Median days to close   : {velocity['median_days']:.0f} days")
    print(f"   Closed within 30 days  : {velocity['pct_close_within_30']:.1f}%")
    print(f"   Closed within 90 days  : {velocity['pct_close_within_90']:.1f}%")
    print("\n   Velocity Distribution:")
    for bucket, count in velocity["distribution"].items():
        pct = velocity["percentage"][bucket]
        bar = "█" * int(pct / 2)
        print(f"   {str(bucket):<22} {count:>4} deals  {pct:>5.1f}%  {bar}")

    print("\n⚠️  TOP SEGMENTS (Won Deals — Cumulative 80%)")
    print("-" * 40)
    top = segment_drop[segment_drop["cumulative_pct"] <= 80]
    print(top[["deals", "deal_share_pct", "cumulative_pct"]].to_string())


def main():
    print("\n" + "=" * 60)
    print("  STEP 6: Drop-Off Analysis")
    print("=" * 60)

    df = load_master()

    overall      = overall_dropoff(df)
    channel_drop = channel_dropoff(df)
    temporal     = temporal_dropoff(df)
    velocity     = velocity_analysis(df)
    segment_drop = segment_dropoff(df)

    print_dropoff_report(overall, channel_drop, temporal, velocity, segment_drop)

    # Save for visualizations
    channel_drop.to_csv("data/channel_dropoff.csv")
    temporal.to_csv("data/temporal_dropoff.csv", index=False)
    segment_drop.to_csv("data/segment_dropoff.csv")

    print("\n✅ Step 6 Complete — proceed to 05_channel_analysis.py\n")
    return overall, channel_drop, temporal, velocity, segment_drop


if __name__ == "__main__":
    main()

"""
====================================================================
STEP 9 & 10 — Insights & Optimization Recommendations
====================================================================
Marketing Funnel & Conversion Analysis | Olist B2B
====================================================================
Synthesizes all analysis into actionable business recommendations
with prioritization, expected impact, and implementation guidance.
====================================================================
"""

import pandas as pd
import numpy as np

MASTER_PATH = "data/clean_master.csv"


def load_master() -> pd.DataFrame:
    return pd.read_csv(MASTER_PATH, parse_dates=["first_contact_date", "won_date"])


def generate_insights(df: pd.DataFrame) -> list[dict]:
    """
    Generate data-driven insights from the funnel analysis.
    Returns structured insight objects with evidence.
    """
    won  = df[df["converted"] == 1]
    lost = df[df["converted"] == 0]

    ch = df.groupby("channel_group").agg(
        mqls=("mql_id", "count"),
        won=("converted", "sum"),
    )
    ch["conv_rate"] = ch["won"] / ch["mqls"] * 100

    best_ch  = ch["conv_rate"].idxmax()
    worst_ch = ch.loc[ch["mqls"] >= 100, "conv_rate"].idxmin()

    insights = [
        {
            "id":       1,
            "category": "Funnel Health",
            "title":    "Only 1 in 10 MQLs converts — funnel has significant leakage",
            "evidence": f"Of 8,000 MQLs, only 842 converted (10.5%). "
                        f"89.5% of leads are lost before becoming sellers.",
            "severity": "HIGH",
            "opportunity": "Each 1% lift = ~80 additional sellers",
        },
        {
            "id":       2,
            "category": "Channel Performance",
            "title":    f"{best_ch} delivers the highest conversion rate",
            "evidence": f"{best_ch} converts at {ch.loc[best_ch, 'conv_rate']:.1f}% "
                        f"vs 10.5% overall average.",
            "severity": "HIGH",
            "opportunity": "Reallocating budget toward high-converting channels improves ROI",
        },
        {
            "id":       3,
            "category": "Channel Performance",
            "title":    "Organic Search dominates volume but lags in conversion quality",
            "evidence": f"Organic Search sends 28.7% of all MQLs ({ch.loc['Organic','mqls']:,}) "
                        f"but converts at {ch.loc['Organic','conv_rate']:.1f}%.",
            "severity": "MEDIUM",
            "opportunity": "Better landing page targeting can improve organic quality",
        },
        {
            "id":       4,
            "category": "Data Quality",
            "title":    "1,099 leads have 'Unknown' origin — attribution gap",
            "evidence": f"13.7% of all MQLs have no tracked source. "
                        f"These leads convert at {ch.loc['Unknown','conv_rate']:.1f}%.",
            "severity": "MEDIUM",
            "opportunity": "UTM tracking fixes could reveal significant budget optimization",
        },
        {
            "id":       5,
            "category": "Segment Strategy",
            "title":    "Home Decor and Health Beauty are top seller segments",
            "evidence": f"Home Decor (105 deals) and Health Beauty (93 deals) account for "
                        f"23.5% of all closed deals combined.",
            "severity": "LOW",
            "opportunity": "Vertical-specific campaigns for these segments could lift volume",
        },
        {
            "id":       6,
            "category": "Sales Velocity",
            "title":    "Median deal close time is 95 days — long sales cycle",
            "evidence": f"Median days to close: {won['days_to_close'].median():.0f} days. "
                        f"Only {(won['days_to_close'] <= 30).mean()*100:.1f}% close within 30 days.",
            "severity": "MEDIUM",
            "opportunity": "Structured nurture sequences could compress the sales cycle",
        },
        {
            "id":       7,
            "category": "Lead Profiling",
            "title":    "21% of won deals lack behaviour profile data",
            "evidence": f"{won['lead_behaviour_profile'].eq('unknown').mean()*100:.1f}% of "
                        f"closed deals have no CRM behaviour profile recorded.",
            "severity": "LOW",
            "opportunity": "Better profiling enables personalized SDR outreach",
        },
        {
            "id":       8,
            "category": "Channel Mix",
            "title":    "Email channel is significantly underutilized",
            "evidence": f"Email sends only {ch.loc['Email','mqls']:,} MQLs (6.2% of total) "
                        f"but converts at {ch.loc['Email','conv_rate']:.1f}%.",
            "severity": "HIGH",
            "opportunity": "Investing in email campaigns could yield strong ROI",
        },
    ]
    return insights


def generate_recommendations() -> list[dict]:
    """
    Prioritized optimization recommendations with implementation guidance.

    Prioritization framework:
    - Priority 1 (Quick Wins): High impact, low effort, < 30 days
    - Priority 2 (Strategic):  High impact, medium effort, 30–90 days
    - Priority 3 (Long-term):  Medium impact, higher effort, 90+ days
    """
    return [
        # ── PRIORITY 1: QUICK WINS ────────────────────────────────
        {
            "priority":    1,
            "label":       "🎯 QUICK WIN",
            "title":       "Fix UTM tracking for all campaigns immediately",
            "problem":     "1,099 leads (13.7%) have no source attribution",
            "action":      "Audit and enforce UTM parameters on all ad links, "
                           "email campaigns, and social posts. Use a UTM builder template.",
            "metric":      "Unknown origin leads → < 2% within 60 days",
            "effort":      "Low (1 week)",
            "impact":      "High — reveals hidden budget performance",
            "team":        "Marketing Operations",
        },
        {
            "priority":    1,
            "label":       "🎯 QUICK WIN",
            "title":       "Increase email marketing budget by 2×",
            "problem":     "Email is underweight in the channel mix despite strong conversion",
            "action":      "Launch weekly nurture sequences targeting MQLs in pipeline. "
                           "A/B test subject lines and CTAs. Segment by business type.",
            "metric":      "Email MQL volume from 493 → 1,000+ per cycle",
            "effort":      "Low (2 weeks to set up)",
            "impact":      "High — email historically scales well for B2B",
            "team":        "Email Marketing",
        },
        {
            "priority":    1,
            "label":       "🎯 QUICK WIN",
            "title":       "Create vertical-specific landing pages for Home Decor & Health Beauty",
            "problem":     "Generic landing pages don't speak to high-converting verticals",
            "action":      "Build 2 dedicated landing pages with industry-specific copy, "
                           "testimonials, and targeted CTAs for top seller segments.",
            "metric":      "5–10% lift in conversion from organic/paid traffic",
            "effort":      "Low-Medium (3 weeks)",
            "impact":      "Medium-High",
            "team":        "Web / Content",
        },
        # ── PRIORITY 2: STRATEGIC INITIATIVES ────────────────────
        {
            "priority":    2,
            "label":       "📈 STRATEGIC",
            "title":       "Build a lead scoring model to prioritize SDR outreach",
            "problem":     "SDRs treat all 8,000 MQLs equally — diluting effort",
            "action":      "Build a logistic regression model using available features "
                           "(origin, lead_type, business_segment) to score each MQL. "
                           "Focus SDR time on top-quartile scores.",
            "metric":      "SDR efficiency: same headcount, 20% more deals",
            "effort":      "Medium (4–6 weeks, requires data team)",
            "impact":      "High — standard B2B best practice",
            "team":        "Data Science + Sales",
        },
        {
            "priority":    2,
            "label":       "📈 STRATEGIC",
            "title":       "Launch referral program for existing sellers",
            "problem":     "Referral converts at 10.9% — near-average with only 284 leads",
            "action":      "Design an incentive structure (fee reduction, premium listing) "
                           "for sellers who refer new sellers. Track via unique referral codes.",
            "metric":      "Referral MQL volume → 500+ per quarter",
            "effort":      "Medium (6 weeks to design and launch)",
            "impact":      "High — referral leads are pre-qualified by peers",
            "team":        "Partnerships + Product",
        },
        {
            "priority":    2,
            "label":       "📈 STRATEGIC",
            "title":       "SDR nurture sequence for long-cycle leads",
            "problem":     "Median close time is 95 days; many leads go cold",
            "action":      "Build a 12-touch nurture sequence over 90 days: "
                           "welcome → case study → ROI calculator → demo invite → urgency. "
                           "Automate with CRM workflows.",
            "metric":      "Reduce median close time by 20% (76 days target)",
            "effort":      "Medium (6–8 weeks to design and automate)",
            "impact":      "Medium — compresses revenue cycle",
            "team":        "Sales Ops + SDR Team",
        },
        # ── PRIORITY 3: LONG-TERM ─────────────────────────────────
        {
            "priority":    3,
            "label":       "🔭 LONG-TERM",
            "title":       "Reallocate paid spend toward Direct and Email vs. Organic",
            "problem":     "Paid search has modest conversion; Direct converts highest",
            "action":      "Run a 90-day media mix modelling exercise. "
                           "Shift 15% of paid search budget toward branded keywords "
                           "that drive direct traffic, and double email retargeting spend.",
            "metric":      "Overall funnel conversion from 10.5% → 12.5% in 6 months",
            "effort":      "Medium-High (requires media planning overhaul)",
            "impact":      "High",
            "team":        "Performance Marketing + Analytics",
        },
        {
            "priority":    3,
            "label":       "🔭 LONG-TERM",
            "title":       "Implement behaviour-based CRM profiling at MQL entry",
            "problem":     "21% of closed deals have unknown behaviour profile",
            "action":      "Add 3 qualifying questions to the MQL intake form that map "
                           "to CRM profiles (cat/eagle/wolf/shark). Train SDRs to "
                           "adapt pitch style per profile.",
            "metric":      "Profile coverage → 95%+; improve win rate by profile type",
            "effort":      "High (form redesign + SDR training)",
            "impact":      "Medium — enables personalized playbooks",
            "team":        "Sales Enablement + Marketing Ops",
        },
    ]


def print_insights_report(insights: list[dict], recs: list[dict]) -> None:
    sep = "=" * 70

    print(f"\n{sep}")
    print("  STEP 9: KEY INSIGHTS")
    print(sep)

    for ins in insights:
        icon = {"HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🟢"}.get(ins["severity"], "⚪")
        print(f"\n  {icon} [{ins['category'].upper()}] #{ins['id']}: {ins['title']}")
        print(f"     Evidence   : {ins['evidence']}")
        print(f"     Opportunity: {ins['opportunity']}")

    print(f"\n{sep}")
    print("  STEP 10: OPTIMIZATION RECOMMENDATIONS")
    print(sep)

    for priority in [1, 2, 3]:
        label = {1: "PRIORITY 1 — QUICK WINS (< 30 days)",
                 2: "PRIORITY 2 — STRATEGIC (30–90 days)",
                 3: "PRIORITY 3 — LONG-TERM (90+ days)"}[priority]
        print(f"\n  ── {label} ──")

        for rec in recs:
            if rec["priority"] != priority:
                continue
            print(f"\n  {rec['label']}  {rec['title']}")
            print(f"     Problem : {rec['problem']}")
            print(f"     Action  : {rec['action']}")
            print(f"     Metric  : {rec['metric']}")
            print(f"     Effort  : {rec['effort']}   |   Impact: {rec['impact']}")
            print(f"     Owner   : {rec['team']}")


def main():
    print("\n" + "=" * 70)
    print("  STEP 9 & 10: Insights & Optimization Recommendations")
    print("=" * 70)

    df       = load_master()
    insights = generate_insights(df)
    recs     = generate_recommendations()

    print_insights_report(insights, recs)

    print("\n✅ Step 9 & 10 Complete — proceed to generate final report\n")
    return insights, recs


if __name__ == "__main__":
    main()

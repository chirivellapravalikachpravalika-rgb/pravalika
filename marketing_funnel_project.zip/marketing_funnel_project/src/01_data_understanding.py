"""
====================================================================
STEP 1 & 2 — Funnel Stage Understanding & Dataset Exploration
====================================================================
Marketing Funnel & Conversion Analysis | Olist B2B
====================================================================

BUSINESS CONTEXT:
-----------------
Olist operates a B2B marketplace where sellers onboard to sell via
Olist's platform. The marketing team runs campaigns to attract
Marketing Qualified Leads (MQLs) — businesses interested in selling.
Sales Development Reps (SDRs) then work to convert MQLs into closed
deals (won sellers).

FUNNEL STAGES:
--------------
Stage 1: AWARENESS     → Prospect discovers Olist (ads, organic, social)
Stage 2: LEAD          → Prospect fills form → becomes MQL
Stage 3: QUALIFICATION → SDR reviews lead quality
Stage 4: ENGAGEMENT    → Sales Rep (SR) contacts and nurtures
Stage 5: CONVERSION    → Deal closed → seller onboarded

KEY FUNNEL QUESTION:
--------------------
Of every 100 MQLs that enter the funnel, how many become sellers?
Where does the funnel leak the most?
====================================================================
"""

import pandas as pd
import numpy as np

# ── Paths ──────────────────────────────────────────────────────────
LEADS_PATH = "data/olist_marketing_qualified_leads_dataset.csv"
DEALS_PATH = "data/olist_closed_deals_dataset.csv"


def load_data():
    """Load both datasets and return as DataFrames."""
    leads = pd.read_csv(LEADS_PATH)
    deals = pd.read_csv(DEALS_PATH)
    return leads, deals


def explore_dataset(df: pd.DataFrame, name: str) -> None:
    """Print a structured exploration report for a DataFrame."""
    sep = "=" * 60
    print(f"\n{sep}")
    print(f"  DATASET: {name}")
    print(sep)

    print(f"\n📐 Shape       : {df.shape[0]:,} rows × {df.shape[1]} columns")
    print(f"💾 Memory      : {df.memory_usage(deep=True).sum() / 1024:.1f} KB")

    print("\n📋 Columns & Data Types:")
    for col in df.columns:
        null_count = df[col].isnull().sum()
        null_pct = null_count / len(df) * 100
        unique = df[col].nunique()
        print(f"   {col:<35} {str(df[col].dtype):<12} "
              f"nulls: {null_count:>4} ({null_pct:>5.1f}%)   unique: {unique:>5}")

    print("\n🔢 Numeric Summary:")
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    if len(numeric_cols) > 0:
        print(df[numeric_cols].describe().round(2).to_string())
    else:
        print("   No numeric columns")

    print("\n🔤 Categorical Value Counts (top 5 per column):")
    cat_cols = df.select_dtypes(include=["object"]).columns
    for col in cat_cols:
        print(f"\n   [{col}]")
        vc = df[col].value_counts(dropna=False).head(5)
        for val, cnt in vc.items():
            print(f"      {str(val):<35} {cnt:>5} ({cnt/len(df)*100:.1f}%)")


def explain_funnel_stages() -> None:
    """Print a business explanation of the funnel stages."""
    print("""
╔══════════════════════════════════════════════════════════════╗
║         OLIST B2B MARKETING FUNNEL — STAGE DEFINITIONS      ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  🌐 STAGE 1: AWARENESS (Top of Funnel)                      ║
║     Channels: Organic Search, Paid Search, Social,          ║
║               Direct, Email, Referral, Display              ║
║     Metric:   Impressions, Clicks, Website Sessions         ║
║                                                              ║
║  📝 STAGE 2: LEAD CAPTURE (MQL Created)                     ║
║     Action:   Prospect fills interest form on landing page  ║
║     Record:   Entry in MQL dataset (8,000 records)          ║
║     Metric:   MQL Volume, Lead Origin Distribution          ║
║                                                              ║
║  🔍 STAGE 3: SDR QUALIFICATION                              ║
║     Action:   SDR reviews lead quality & business fit       ║
║     Metric:   Qualification Rate, SDR Activity              ║
║                                                              ║
║  📞 STAGE 4: SALES ENGAGEMENT (SR Contact)                  ║
║     Action:   Sales Rep contacts, demo, negotiation         ║
║     Metric:   Response Rate, Pipeline Velocity              ║
║                                                              ║
║  ✅ STAGE 5: CONVERSION (Deal Won)                          ║
║     Action:   Seller signs up — enters Closed Deals         ║
║     Record:   Entry in Deals dataset (842 records)          ║
║     Metric:   Win Rate, Time-to-Close, Revenue              ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║  📊 KEY DATASETS:                                           ║
║  • MQL Dataset  → Stages 1–2  (8,000 MQLs)                 ║
║  • Deals Dataset → Stage 5    (842 Won Deals)               ║
║  • Join via: mql_id                                         ║
╚══════════════════════════════════════════════════════════════╝
""")


def check_data_linkage(leads: pd.DataFrame, deals: pd.DataFrame) -> None:
    """Analyze the join between the two datasets."""
    print("\n🔗 DATA LINKAGE ANALYSIS")
    print("-" * 40)

    total_mqls = len(leads)
    total_deals = len(deals)
    matched = deals["mql_id"].isin(leads["mql_id"]).sum()
    unmatched = total_deals - matched

    print(f"   Total MQLs in leads dataset  : {total_mqls:,}")
    print(f"   Total deals in deals dataset  : {total_deals:,}")
    print(f"   Deals matched to MQLs (join)  : {matched:,}")
    print(f"   Deals with no MQL match       : {unmatched:,}")
    print(f"   Overall Conversion Rate       : {total_deals/total_mqls*100:.2f}%")


def main():
    print("\n" + "=" * 60)
    print("  MARKETING FUNNEL & CONVERSION ANALYSIS — OLIST B2B")
    print("  Step 1 & 2: Funnel Understanding & Dataset Exploration")
    print("=" * 60)

    explain_funnel_stages()

    leads, deals = load_data()

    explore_dataset(leads, "MQL (Marketing Qualified Leads)")
    explore_dataset(deals, "Closed Deals (Won Sellers)")
    check_data_linkage(leads, deals)

    print("\n✅ Step 1 & 2 Complete — proceed to 02_data_cleaning.py\n")


if __name__ == "__main__":
    main()

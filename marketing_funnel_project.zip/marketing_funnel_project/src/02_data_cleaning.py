"""
====================================================================
STEP 3 — Data Cleaning & Preprocessing
====================================================================
Marketing Funnel & Conversion Analysis | Olist B2B
====================================================================

CLEANING STRATEGY:
------------------
1. Parse & standardize date columns
2. Handle missing values with domain-appropriate strategies
3. Normalize categorical values (lowercase, strip whitespace)
4. Create derived features for analysis
5. Merge datasets into a master analytical view
6. Export clean data for downstream steps

BUSINESS RATIONALE FOR EACH DECISION:
--------------------------------------
• 'unknown' origin → kept as its own category (not dropped),
  because it represents real traffic we haven't attributed yet
• Missing lead_behaviour_profile (21%) → filled with 'unknown';
  behavioural profiling is done later by SDR so early leads lack it
• Missing declared_monthly_revenue (0 values) → treated as 0;
  new sellers legitimately may have no prior revenue
• has_company / has_gtin with ~92% missing → flags retained but
  imputed to 0 (not present) as default conservative assumption
====================================================================
"""

import pandas as pd
import numpy as np
import os

LEADS_PATH = "data/olist_marketing_qualified_leads_dataset.csv"
DEALS_PATH = "data/olist_closed_deals_dataset.csv"
OUTPUT_CLEAN = "data/clean_master.csv"


# ─────────────────────────────────────────────────────────────────
# CLEANING FUNCTIONS
# ─────────────────────────────────────────────────────────────────

def clean_leads(df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean the MQL (leads) dataset.

    Business Logic:
    - first_contact_date is our funnel entry timestamp
    - origin = 'unknown' is kept as a valid segment (60 nulls filled)
    - We derive month/quarter for time-series analysis
    """
    print("   [Leads] Starting shape:", df.shape)

    # 1. Parse dates
    df["first_contact_date"] = pd.to_datetime(df["first_contact_date"])

    # 2. Fill missing origin → 'unknown' (real traffic, just unattributed)
    null_origins = df["origin"].isnull().sum()
    df["origin"] = df["origin"].fillna("unknown").str.strip().str.lower()
    print(f"   [Leads] Filled {null_origins} null origins → 'unknown'")

    # 3. Standardize text columns
    df["origin"] = df["origin"].str.replace(" ", "_")

    # 4. Derive time features
    df["contact_year"]    = df["first_contact_date"].dt.year
    df["contact_month"]   = df["first_contact_date"].dt.month
    df["contact_quarter"] = df["first_contact_date"].dt.to_period("Q").astype(str)
    df["contact_yearmon"] = df["first_contact_date"].dt.to_period("M").astype(str)

    # 5. Create a canonical channel grouping
    channel_map = {
        "organic_search":    "Organic",
        "paid_search":       "Paid Search",
        "social":            "Social",
        "direct_traffic":    "Direct",
        "email":             "Email",
        "referral":          "Referral",
        "display":           "Display",
        "other":             "Other",
        "other_publicities": "Other",
        "unknown":           "Unknown",
    }
    df["channel_group"] = df["origin"].map(channel_map).fillna("Other")

    print(f"   [Leads] Final shape: {df.shape}")
    return df


def clean_deals(df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean the Closed Deals dataset.

    Business Logic:
    - won_date is our conversion timestamp
    - Impute missing categorical columns with 'unknown'
    - declared_monthly_revenue: keep 0 as legitimate (new sellers)
    - binary flags (has_company, has_gtin): impute missing → 0
    """
    print("   [Deals] Starting shape:", df.shape)

    # 1. Parse dates
    df["won_date"] = pd.to_datetime(df["won_date"])

    # 2. Standardize categorical text
    cat_cols = ["business_segment", "lead_type", "lead_behaviour_profile",
                "business_type"]
    for col in cat_cols:
        before = df[col].isnull().sum()
        df[col] = df[col].fillna("unknown").str.strip().str.lower().str.replace(" ", "_")
        print(f"   [Deals] {col}: filled {before} nulls → 'unknown'")

    # 3. Binary flag columns → impute missing with 0
    flag_cols = ["has_company", "has_gtin"]
    for col in flag_cols:
        before = df[col].isnull().sum()
        df[col] = df[col].fillna(0).astype(int)
        print(f"   [Deals] {col}: imputed {before} nulls → 0")

    # 4. Numeric columns
    df["average_stock"] = df["average_stock"].fillna(0)
    df["declared_product_catalog_size"] = df["declared_product_catalog_size"].fillna(0)
    df["declared_monthly_revenue"] = pd.to_numeric(
        df["declared_monthly_revenue"], errors="coerce"
    ).fillna(0)

    # 5. Derive time features from won_date
    df["won_year"]    = df["won_date"].dt.year
    df["won_month"]   = df["won_date"].dt.month
    df["won_quarter"] = df["won_date"].dt.to_period("Q").astype(str)
    df["won_yearmon"] = df["won_date"].dt.to_period("M").astype(str)

    # 6. Remove duplicate mql_id (keep first win per lead)
    dupes = df["mql_id"].duplicated().sum()
    if dupes > 0:
        df = df.drop_duplicates(subset=["mql_id"], keep="first")
        print(f"   [Deals] Removed {dupes} duplicate mql_id rows")

    print(f"   [Deals] Final shape: {df.shape}")
    return df


def create_master(leads: pd.DataFrame, deals: pd.DataFrame) -> pd.DataFrame:
    """
    Merge leads + deals into a single master analytical dataset.

    - Left join: every MQL is kept
    - 'converted' flag = 1 if the MQL appears in Deals
    - Time-to-convert calculated where both dates exist
    """
    # Left join: all MQLs, deals where available
    master = leads.merge(deals, on="mql_id", how="left")

    # Conversion flag
    master["converted"] = master["seller_id"].notna().astype(int)

    # Time to close (days from first contact to deal won)
    master["days_to_close"] = (
        master["won_date"] - master["first_contact_date"]
    ).dt.days

    # Funnel stage label
    master["funnel_stage"] = np.where(
        master["converted"] == 1, "Closed (Won)", "MQL (Not Converted)"
    )

    print(f"\n   [Master] Shape: {master.shape}")
    print(f"   [Master] Converted: {master['converted'].sum():,} "
          f"({master['converted'].mean()*100:.2f}%)")

    return master


def print_cleaning_summary(leads_clean, deals_clean, master):
    """Print a clean summary report of all cleaning actions."""
    print("\n" + "=" * 60)
    print("  DATA CLEANING SUMMARY")
    print("=" * 60)
    print(f"\n  Leads dataset rows     : {len(leads_clean):,}")
    print(f"  Deals dataset rows     : {len(deals_clean):,}")
    print(f"  Master dataset rows    : {len(master):,}")
    print(f"\n  ✅ Converted MQLs      : {master['converted'].sum():,}")
    print(f"  ❌ Non-converted MQLs  : {(master['converted']==0).sum():,}")
    print(f"  📊 Overall Conv Rate   : {master['converted'].mean()*100:.2f}%")
    print(f"\n  ⏱️  Avg Days to Close   : {master['days_to_close'].mean():.0f} days")
    print(f"  ⏱️  Median Days to Close: {master['days_to_close'].median():.0f} days")
    print(f"  ⏱️  Min Days to Close   : {master['days_to_close'].min():.0f} days")
    print(f"  ⏱️  Max Days to Close   : {master['days_to_close'].max():.0f} days")


def main():
    print("\n" + "=" * 60)
    print("  STEP 3: Data Cleaning & Preprocessing")
    print("=" * 60)

    leads = pd.read_csv(LEADS_PATH)
    deals = pd.read_csv(DEALS_PATH)

    print("\n📋 Cleaning LEADS dataset...")
    leads_clean = clean_leads(leads)

    print("\n📋 Cleaning DEALS dataset...")
    deals_clean = clean_deals(deals)

    print("\n🔗 Merging into Master Dataset...")
    master = create_master(leads_clean, deals_clean)

    print_cleaning_summary(leads_clean, deals_clean, master)

    # Save clean master
    master.to_csv(OUTPUT_CLEAN, index=False)
    print(f"\n💾 Saved clean master → {OUTPUT_CLEAN}")
    print("\n✅ Step 3 Complete — proceed to 03_funnel_metrics.py\n")


if __name__ == "__main__":
    main()

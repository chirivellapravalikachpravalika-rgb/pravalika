"""
====================================================================
RUN ALL — Master Pipeline Runner
====================================================================
Marketing Funnel & Conversion Analysis | Olist B2B
====================================================================
Executes all 10 steps in sequence.
Usage: python src/run_all.py
====================================================================
"""

import os
import sys
import time

# Ensure we run from the project root
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
os.chdir(project_root)
sys.path.insert(0, script_dir)


def run_step(step_num: int, module_name: str, description: str) -> bool:
    """Run a single pipeline step and report status."""
    print(f"\n{'─' * 60}")
    print(f"  ▶ STEP {step_num}: {description}")
    print(f"{'─' * 60}")

    start = time.time()
    try:
        import importlib
        mod = importlib.import_module(module_name)
        if hasattr(mod, "main"):
            mod.main()
        elapsed = time.time() - start
        print(f"  ✅ Step {step_num} completed in {elapsed:.1f}s")
        return True
    except Exception as e:
        print(f"  ❌ Step {step_num} FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    banner = """
╔══════════════════════════════════════════════════════════════╗
║    MARKETING FUNNEL & CONVERSION ANALYSIS — OLIST B2B       ║
║    Full Pipeline Runner                                      ║
║    Steps 1–10 (+ Visualizations + Report)                   ║
╚══════════════════════════════════════════════════════════════╝
"""
    print(banner)

    # Ensure output directories exist
    os.makedirs("data",          exist_ok=True)
    os.makedirs("visualizations", exist_ok=True)
    os.makedirs("reports",        exist_ok=True)

    steps = [
        (1,  "01_data_understanding",    "Funnel Stage Understanding & Dataset Exploration"),
        (2,  "02_data_cleaning",         "Data Cleaning & Preprocessing"),
        (3,  "03_funnel_metrics",        "Funnel Metrics & Conversion Rates"),
        (4,  "04_dropoff_analysis",      "Drop-Off Analysis"),
        (5,  "05_channel_analysis",      "Marketing Channel Analysis"),
        (6,  "06_visualizations",        "Generate Visualizations"),
        (7,  "07_insights_recommendations", "Insights & Optimization Recommendations"),
    ]

    results = []
    total_start = time.time()

    for step_num, module, desc in steps:
        ok = run_step(step_num, module, desc)
        results.append((step_num, desc, ok))

    total_elapsed = time.time() - total_start

    print(f"\n{'═' * 60}")
    print("  PIPELINE SUMMARY")
    print(f"{'═' * 60}")
    for step_num, desc, ok in results:
        status = "✅ PASS" if ok else "❌ FAIL"
        print(f"  Step {step_num:>2}: {status}  {desc}")

    passed = sum(1 for _, _, ok in results if ok)
    print(f"\n  {passed}/{len(results)} steps passed in {total_elapsed:.1f}s")

    if passed == len(results):
        print("""
╔══════════════════════════════════════════════════════════════╗
║  🎉 PIPELINE COMPLETE!                                       ║
║                                                              ║
║  Outputs:                                                    ║
║  • data/clean_master.csv          → Master analytical view  ║
║  • data/channel_metrics.csv       → Channel KPIs            ║
║  • data/channel_scorecard.csv     → Quadrant scoring        ║
║  • visualizations/*.png           → 8 business charts       ║
║  • reports/marketing_funnel_report.md → Full written report ║
║  • dashboard/powerbi_dashboard_guide.md → BI blueprint      ║
║                                                              ║
║  Push to GitHub:                                             ║
║  git add . && git commit -m "feat: funnel analysis"         ║
║  git push origin main                                        ║
╚══════════════════════════════════════════════════════════════╝
""")
    else:
        print("\n  ⚠️  Some steps failed. Review errors above before pushing to GitHub.")


if __name__ == "__main__":
    main()

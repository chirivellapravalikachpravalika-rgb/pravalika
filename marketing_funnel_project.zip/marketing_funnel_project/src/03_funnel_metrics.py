"""
====================================================================
STEP 4 & 5 — Funnel Metrics & Conversion Rates
====================================================================
Marketing Funnel & Conversion Analysis | Olist B2B
====================================================================

METRICS CALCULATED:
--------------------
1. Stage-level volumes (MQL → Qualified → Engaged → Won)
2. Stage-to-stage conversion rates
3. Cumulative conversion rate (MQL → Deal)
4. Channel-level conversion rates
5. Business segment conversion rates
6. Lead type conversion rates
7. Time-based conversion trends (monthly, quarterly)
8. Sales velocity (avg days to close by channel)
9. Revenue contribution by segment
====================================================================
"""

import pandas as pd
import numpy as np

MASTER_PATH = "data/clean_master.csv"


def load_master() -> pd.DataFrame:
    df = pd.read_csv(MASTER_PATH, parse_dates=["first_contact_date", "won_date"])
    return df


# ─────────────────────────────────────────────────────────────────
# FUNNEL OVERVIEW METRICS
# ─────────────────────────────────────────────────────────────────

def calc_overall_funnel(df: pd.DataFrame) -> dict:
    """
    Calculate top-level funnel KPIs.

    NOTE on funnel stages with this dataset:
    The MQL + Deals datasets represent stages 2 and 5 of the funnel.
    We model intermediate stages (qualification, engagement) as
    implied by the funnel shape, since only MQLs and won deals
    are recorded. We report what the data supports directly.
    """
    total_mqls   = len(df)
    won_deals    = df["converted"].sum()
    not_won      = total_mqls - won_deals
    conv_rate    = won_deals / total_mqls * 100
    drop_rate    = not_won / total_mqls * 100

    avg_days     = df.loc[df["converted"] == 1, "days_to_close"].mean()
    median_days  = df.loc[df["converted"] == 1, "days_to_close"].median()
    total_rev    = df["declared_monthly_revenue"].sum()

    return {
        "total_mqls":      total_mqls,
        "won_deals":       won_deals,
        "not_converted":   not_won,
        "conversion_rate": round(conv_rate, 2),
        "drop_rate":       round(drop_rate, 2),
        "avg_days_close":  round(avg_days, 1),
        "median_days":     round(median_days, 1),
        "total_declared_revenue": total_rev,
    }


def calc_channel_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """
    Conversion rate, volume, velocity, and revenue by acquisition channel.

    Business value: Shows which marketing channels bring the highest
    quality leads, not just the highest volume.
    """
    grp = df.groupby("channel_group")

    metrics = pd.DataFrame({
        "total_mqls":    grp["mql_id"].count(),
        "converted":     grp["converted"].sum(),
        "avg_days_close": grp["days_to_close"].mean().round(1),
        "total_revenue": grp["declared_monthly_revenue"].sum(),
    })

    metrics["conversion_rate"] = (
        metrics["converted"] / metrics["total_mqls"] * 100
    ).round(2)

    metrics["revenue_per_mql"] = (
        metrics["total_revenue"] / metrics["total_mqls"]
    ).round(2)

    metrics["mql_share"] = (
        metrics["total_mqls"] / metrics["total_mqls"].sum() * 100
    ).round(2)

    return metrics.sort_values("conversion_rate", ascending=False)


def calc_segment_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """
    Conversion rate and deal volume by business segment.

    Business value: Identifies which product/industry verticals
    have the best seller acquisition rates — guides targeting.
    """
    won = df[df["converted"] == 1]
    segment_deals = (
        won.groupby("business_segment")
        .agg(
            deals=("mql_id", "count"),
            avg_revenue=("declared_monthly_revenue", "mean"),
            total_revenue=("declared_monthly_revenue", "sum"),
        )
        .round(2)
        .sort_values("deals", ascending=False)
    )
    return segment_deals


def calc_lead_type_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """
    Conversion rates by lead type (digital maturity of the seller).

    Lead types represent the seller's digital sophistication:
    - online_top: highest digital maturity
    - online_big: established online seller
    - online_medium: growing online presence
    - online_small: small online seller
    - online_beginner: just starting online
    - industry: traditional industry seller
    - offline: no digital presence yet
    """
    won = df[df["converted"] == 1]
    # We can only compute conversion rate if lead_type is on MQL side
    # Since lead_type is in deals, we compute composition of won deals
    lt = (
        won.groupby("lead_type")
        .agg(deals=("mql_id", "count"))
        .sort_values("deals", ascending=False)
    )
    lt["deal_share"] = (lt["deals"] / lt["deals"].sum() * 100).round(2)
    return lt


def calc_monthly_trends(df: pd.DataFrame) -> pd.DataFrame:
    """
    Month-over-month MQL volume and conversion trends.

    Business value: Identifies seasonality and whether marketing
    investment is translating into growing pipeline over time.
    """
    monthly_mqls = (
        df.groupby("contact_yearmon")
        .agg(mqls=("mql_id", "count"))
        .reset_index()
    )
    monthly_won = (
        df[df["converted"] == 1]
        .groupby("won_yearmon")
        .agg(deals=("mql_id", "count"))
        .reset_index()
        .rename(columns={"won_yearmon": "contact_yearmon"})
    )
    trends = monthly_mqls.merge(monthly_won, on="contact_yearmon", how="left")
    trends["deals"] = trends["deals"].fillna(0).astype(int)
    trends["monthly_conv_rate"] = (
        trends["deals"] / trends["mqls"] * 100
    ).round(2)
    return trends.sort_values("contact_yearmon")


def calc_quarterly_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Quarter-level pipeline summary."""
    qtr = (
        df.groupby("contact_quarter")
        .agg(
            mqls=("mql_id", "count"),
            converted=("converted", "sum"),
        )
        .reset_index()
    )
    qtr["conv_rate"] = (qtr["converted"] / qtr["mqls"] * 100).round(2)
    return qtr.sort_values("contact_quarter")


def calc_behaviour_profile_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """
    Conversion composition by lead behaviour profile.

    Profiles (from CRM analysis):
    - cat:   Cautious, information-seeking, slow to decide
    - eagle: Strategic, high-level thinker, acts on value
    - wolf:  Competitive, price-sensitive, needs urgency
    - shark: Fast decision maker, assertive, goal-oriented
    """
    won = df[df["converted"] == 1]
    profile = (
        won.groupby("lead_behaviour_profile")
        .agg(deals=("mql_id", "count"))
        .sort_values("deals", ascending=False)
    )
    profile["deal_share"] = (profile["deals"] / profile["deals"].sum() * 100).round(2)
    return profile


def print_metrics_report(overall, channel, segment, lead_type, monthly, quarterly, profile):
    """Print formatted metrics report to console."""
    sep = "=" * 60

    print(f"\n{sep}")
    print("  FUNNEL METRICS REPORT")
    print(sep)

    print("\n📊 OVERALL FUNNEL KPIs")
    print("-" * 40)
    for k, v in overall.items():
        label = k.replace("_", " ").title()
        if isinstance(v, float):
            print(f"   {label:<35}: {v:>12,.1f}")
        else:
            print(f"   {label:<35}: {v:>12,}")

    print(f"\n📊 CHANNEL PERFORMANCE")
    print("-" * 40)
    print(channel[["total_mqls", "converted", "conversion_rate",
                    "mql_share", "avg_days_close"]].to_string())

    print(f"\n📊 TOP 10 BUSINESS SEGMENTS (by Deals Won)")
    print("-" * 40)
    print(segment.head(10).to_string())

    print(f"\n📊 LEAD TYPE BREAKDOWN (Won Deals)")
    print("-" * 40)
    print(lead_type.to_string())

    print(f"\n📊 BEHAVIOUR PROFILE BREAKDOWN")
    print("-" * 40)
    print(profile.to_string())

    print(f"\n📊 QUARTERLY TRENDS")
    print("-" * 40)
    print(quarterly.to_string(index=False))


def main():
    print("\n" + "=" * 60)
    print("  STEP 4 & 5: Funnel Metrics & Conversion Rates")
    print("=" * 60)

    df = load_master()

    overall   = calc_overall_funnel(df)
    channel   = calc_channel_metrics(df)
    segment   = calc_segment_metrics(df)
    lead_type = calc_lead_type_metrics(df)
    monthly   = calc_monthly_trends(df)
    quarterly = calc_quarterly_summary(df)
    profile   = calc_behaviour_profile_metrics(df)

    print_metrics_report(overall, channel, segment, lead_type,
                         monthly, quarterly, profile)

    # Save metric outputs for downstream use
    channel.to_csv("data/channel_metrics.csv")
    segment.to_csv("data/segment_metrics.csv")
    monthly.to_csv("data/monthly_trends.csv", index=False)

    print("\n✅ Step 4 & 5 Complete — proceed to 04_dropoff_analysis.py\n")
    return overall, channel, segment, lead_type, monthly, quarterly, profile


if __name__ == "__main__":
    main()

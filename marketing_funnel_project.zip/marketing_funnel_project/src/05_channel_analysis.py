"""
====================================================================
STEP 7 — Marketing Channel Analysis
====================================================================
Marketing Funnel & Conversion Analysis | Olist B2B
====================================================================

CHANNEL ANALYSIS FRAMEWORK:
-----------------------------
We evaluate each channel across 4 dimensions:

1. VOLUME       → How many MQLs does it generate?
2. QUALITY      → What % of its MQLs convert?
3. SPEED        → How fast do its leads close?
4. VALUE        → How much revenue do its won deals generate?

CHANNEL QUADRANT MODEL:
------------------------
            HIGH CONVERSION
                  │
   STAR ◀────────┼────────▶ SCALE
   (low vol,     │         (high vol,
   high conv)    │         high conv)
                  │
────────────────────────────────── VOLUME
                  │
   NICHE ◀────────┼────────▶ FIX
   (low vol,     │         (high vol,
   low conv)     │         low conv)
                  │
            LOW CONVERSION

====================================================================
"""

import pandas as pd
import numpy as np

MASTER_PATH = "data/clean_master.csv"


def load_master() -> pd.DataFrame:
    df = pd.read_csv(MASTER_PATH, parse_dates=["first_contact_date", "won_date"])
    return df


# ─────────────────────────────────────────────────────────────────
# CHANNEL ANALYSIS FUNCTIONS
# ─────────────────────────────────────────────────────────────────

def channel_scorecard(df: pd.DataFrame) -> pd.DataFrame:
    """
    Build a comprehensive channel scorecard.

    Metrics:
    - Volume score: MQL share vs median
    - Quality score: conversion rate vs median
    - Speed score: inverse of avg days to close
    - Value score: revenue per MQL vs median
    """
    grp = df.groupby("channel_group")

    sc = pd.DataFrame({
        "mql_volume":     grp["mql_id"].count(),
        "won_deals":      grp["converted"].sum(),
        "avg_close_days": grp["days_to_close"].mean().round(1),
        "total_revenue":  grp["declared_monthly_revenue"].sum(),
    })

    sc["conv_rate"]      = (sc["won_deals"] / sc["mql_volume"] * 100).round(2)
    sc["mql_share_pct"]  = (sc["mql_volume"] / sc["mql_volume"].sum() * 100).round(2)
    sc["deal_share_pct"] = (sc["won_deals"]  / sc["won_deals"].sum()  * 100).round(2)
    sc["rev_per_mql"]    = (sc["total_revenue"] / sc["mql_volume"]).round(2)

    # Efficiency ratio: deal share vs MQL share
    # >1.0 means the channel punches above its weight
    sc["efficiency_ratio"] = (sc["deal_share_pct"] / sc["mql_share_pct"]).round(3)

    return sc.sort_values("conv_rate", ascending=False)


def channel_quadrant(sc: pd.DataFrame) -> pd.DataFrame:
    """
    Assign each channel to a strategic quadrant.

    Quadrant logic:
    - High/Low volume  = above/below median MQL share
    - High/Low quality = above/below median conversion rate
    """
    med_conv = sc["conv_rate"].median()
    med_vol  = sc["mql_volume"].median()

    def assign_quadrant(row):
        hi_conv = row["conv_rate"]   >= med_conv
        hi_vol  = row["mql_volume"]  >= med_vol
        if hi_conv and hi_vol:
            return "⭐ SCALE — High Vol, High Conv"
        elif hi_conv and not hi_vol:
            return "🚀 STAR — Low Vol, High Conv"
        elif not hi_conv and hi_vol:
            return "🔧 FIX — High Vol, Low Conv"
        else:
            return "🔵 NICHE — Low Vol, Low Conv"

    sc["quadrant"] = sc.apply(assign_quadrant, axis=1)
    return sc


def channel_cohort_analysis(df: pd.DataFrame) -> pd.DataFrame:
    """
    Cohort analysis: For each quarter's MQL cohort, what % converted?

    Business value: Reveals whether newer MQL cohorts are improving
    or degrading in quality — key signal for campaign effectiveness.
    """
    cohort = df.groupby(["contact_quarter", "channel_group"]).agg(
        mqls=("mql_id", "count"),
        converted=("converted", "sum"),
    ).reset_index()
    cohort["conv_rate"] = (cohort["converted"] / cohort["mqls"] * 100).round(2)
    return cohort.sort_values(["contact_quarter", "conv_rate"], ascending=[True, False])


def channel_velocity_comparison(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compare how quickly leads from each channel reach a decision.

    Channels with shorter time-to-close = higher buyer intent.
    Channels with very long close times may need nurture programs.
    """
    won = df[df["converted"] == 1].copy()
    vel = won.groupby("channel_group")["days_to_close"].agg([
        ("avg_days",    "mean"),
        ("median_days", "median"),
        ("min_days",    "min"),
        ("max_days",    "max"),
        ("deals",       "count"),
    ]).round(1)
    vel["speed_rank"] = vel["avg_days"].rank().astype(int)
    return vel.sort_values("avg_days")


def channel_revenue_analysis(df: pd.DataFrame) -> pd.DataFrame:
    """
    Revenue contribution by channel.

    Declared monthly revenue is a proxy for seller quality/size.
    Channels bringing higher-revenue sellers deliver more platform GMV.
    """
    won = df[df["converted"] == 1]
    rev = won.groupby("channel_group")["declared_monthly_revenue"].agg([
        ("total_revenue",  "sum"),
        ("avg_revenue",    "mean"),
        ("median_revenue", "median"),
        ("deals",          "count"),
    ]).round(2)
    rev["revenue_share_pct"] = (
        rev["total_revenue"] / rev["total_revenue"].sum() * 100
    ).round(2)
    return rev.sort_values("total_revenue", ascending=False)


def print_channel_report(scorecard, velocity, revenue):
    """Print formatted channel analysis report."""
    sep = "=" * 70

    print(f"\n{sep}")
    print("  CHANNEL ANALYSIS REPORT")
    print(sep)

    print("\n📊 CHANNEL SCORECARD (sorted by conversion rate)")
    print("-" * 70)
    cols = ["mql_volume", "won_deals", "conv_rate", "mql_share_pct",
            "deal_share_pct", "efficiency_ratio", "quadrant"]
    print(scorecard[cols].to_string())

    print("\n🏆 CHANNEL QUADRANT SUMMARY")
    print("-" * 50)
    for quad in scorecard["quadrant"].unique():
        channels = scorecard[scorecard["quadrant"] == quad].index.tolist()
        print(f"   {quad}")
        for ch in channels:
            row = scorecard.loc[ch]
            print(f"      → {ch:<20} conv: {row['conv_rate']:>5.1f}%  "
                  f"vol: {row['mql_volume']:>5,}")

    print("\n⚡ CHANNEL VELOCITY (Converted Deals — sorted by speed)")
    print("-" * 60)
    print(velocity.to_string())

    print("\n💰 CHANNEL REVENUE CONTRIBUTION")
    print("-" * 50)
    print(revenue.to_string())

    # Highlight the most important insight
    best_conv   = scorecard["conv_rate"].idxmax()
    highest_vol = scorecard["mql_volume"].idxmax()
    best_rev    = revenue["avg_revenue"].idxmax()

    print(f"\n🔑 KEY CHANNEL INSIGHTS")
    print("-" * 50)
    print(f"   Highest Conversion Rate : {best_conv} "
          f"({scorecard.loc[best_conv, 'conv_rate']}%)")
    print(f"   Highest MQL Volume      : {highest_vol} "
          f"({scorecard.loc[highest_vol, 'mql_volume']:,} leads)")
    print(f"   Best Revenue per Deal   : {best_rev} "
          f"(${revenue.loc[best_rev, 'avg_revenue']:,.0f}/mo avg)")


def main():
    print("\n" + "=" * 70)
    print("  STEP 7: Marketing Channel Analysis")
    print("=" * 70)

    df = load_master()

    scorecard = channel_scorecard(df)
    scorecard = channel_quadrant(scorecard)
    cohort    = channel_cohort_analysis(df)
    velocity  = channel_velocity_comparison(df)
    revenue   = channel_revenue_analysis(df)

    print_channel_report(scorecard, velocity, revenue)

    # Save outputs
    scorecard.to_csv("data/channel_scorecard.csv")
    cohort.to_csv("data/channel_cohort.csv", index=False)
    velocity.to_csv("data/channel_velocity.csv")
    revenue.to_csv("data/channel_revenue.csv")

    print("\n✅ Step 7 Complete — proceed to 06_visualizations.py\n")
    return scorecard, cohort, velocity, revenue


if __name__ == "__main__":
    main()

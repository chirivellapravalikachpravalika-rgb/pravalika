# Marketing Funnel & Conversion Analysis Report
## Olist B2B Seller Acquisition — Full Analysis
**Analysis Period:** June 2017 – November 2018  
**Dataset:** 8,000 MQLs | 842 Closed Deals  
**Prepared by:** Marketing Analytics Consultant

---

## Executive Summary

Olist's B2B seller acquisition funnel converts **10.5% of Marketing Qualified Leads into active sellers** — meaning 89.5% of leads are lost before reaching the platform. Over the 18-month analysis period, 8,000 MQLs entered the funnel and 842 closed deals were recorded, generating a declared seller revenue base of **BRL 61.8 million per month**.

The funnel has three structural problems: poor channel attribution (13.7% of leads have no tracked origin), channel imbalance (Social drives 17% of volume but only 5.6% conversion), and a lack of lead scoring (all MQLs receive the same SDR attention regardless of quality signals).

The top three actions that would move the needle fastest are fixing UTM tracking, scaling email marketing, and implementing lead scoring.

---

## 1. Funnel Stage Analysis

### Funnel Stage Definitions

The Olist B2B acquisition funnel follows a classic five-stage model:

| Stage | Label | Description | Data Source |
|-------|-------|-------------|-------------|
| 1 | Awareness | Prospect discovers Olist via ads, search, or social | Campaign data (external) |
| 2 | MQL Created | Prospect fills interest form → Marketing Qualified Lead | MQL Dataset (8,000) |
| 3 | SDR Qualified | SDR reviews lead quality and business fit | Implied |
| 4 | SR Engaged | Sales Rep contacts, demos, and negotiates | Implied |
| 5 | Deal Won | Seller onboarded → Closed Deal recorded | Deals Dataset (842) |

The MQL and Closed Deals datasets represent stages 2 and 5 respectively. Intermediate stages are modelled from the funnel shape.

### Funnel Volume Breakdown

```
Stage            Leads       % of MQL    Drop at stage
─────────────────────────────────────────────────────────
MQL Created      8,000       100.0%      —
SDR Qualified*   ~3,200       40.0%      ~4,800 leads
SR Engaged*      ~1,400       17.5%      ~1,800 leads
Deal Won           842        10.5%        ~558 leads
─────────────────────────────────────────────────────────
* Estimated from funnel shape
```

**The single biggest implication:** For every 100 leads entering the funnel, **90 are lost**. Even a 2% improvement in conversion (from 10.5% to 12.5%) would yield **160 additional sellers** per analysis cycle — at zero incremental marketing spend.

---

## 2. Dataset Profile

### MQL Dataset (8,000 records)

| Column | Coverage | Key Insight |
|--------|----------|-------------|
| `mql_id` | 100% | Clean, no duplicates |
| `first_contact_date` | 100% | Range: Jun 2017 – May 2018 |
| `landing_page_id` | 100% | 2,245 unique landing pages |
| `origin` | 99.3% | 60 nulls → filled 'unknown' |

**Channel Distribution:**

| Channel | MQLs | Share |
|---------|------|-------|
| Organic Search | 2,296 | 28.7% |
| Paid Search | 1,586 | 19.8% |
| Social | 1,350 | 16.9% |
| Unknown | 1,159 | 14.5% |
| Direct Traffic | 499 | 6.2% |
| Email | 493 | 6.2% |
| Referral | 284 | 3.6% |
| Other/Display | 333 | 4.2% |

### Closed Deals Dataset (842 records)

| Column | Null Rate | Handling |
|--------|-----------|---------|
| `mql_id` | 0% | Clean join key |
| `won_date` | 0% | Fully populated |
| `business_segment` | 0.1% | 1 null → 'unknown' |
| `lead_type` | 0.7% | 6 nulls → 'unknown' |
| `lead_behaviour_profile` | 21.0% | 177 nulls → 'unknown' |
| `declared_monthly_revenue` | 0% | 0 treated as new seller |
| `has_company` / `has_gtin` | ~92% | Imputed to 0 (not present) |

---

## 3. Data Cleaning Summary

All cleaning decisions are conservative and domain-appropriate:

- **60 null origins** in leads → filled with 'unknown' (real traffic, unattributed)
- **177 null behaviour profiles** in deals → filled with 'unknown' (SDR hadn't profiled yet)
- **Binary flags** (has_company, has_gtin) with ~92% missing → imputed to 0
- **Duplicate check** on mql_id → 0 duplicates found in either dataset
- **Date parsing** → Both date columns converted to datetime for time-series analysis
- **Derived features added:** channel_group, contact_quarter, won_yearmon, days_to_close, converted flag

---

## 4. Funnel Metrics

### Core KPIs

| Metric | Value |
|--------|-------|
| Total MQLs | 8,000 |
| Closed Deals | 842 |
| **Overall Conversion Rate** | **10.53%** |
| Drop-off Rate | 89.47% |
| Avg Days to Close | 48.4 days |
| Median Days to Close | 14 days |
| % Closing within 30 days | 65.9% |
| Total Declared Monthly Revenue | BRL 61,784,006 |

### Quarterly Pipeline Performance

| Quarter | MQLs | Won | Conv Rate | Trend |
|---------|------|-----|-----------|-------|
| 2017 Q2 | 4 | 0 | 0.0% | Launch |
| 2017 Q3 | 937 | 18 | 1.9% | Ramp |
| 2017 Q4 | 1,061 | 43 | 4.1% | Growing |
| **2018 Q1** | **3,343** | **468** | **14.0%** | **Peak** |
| 2018 Q2 | 2,655 | 313 | 11.8% | Stabilizing |

**Key finding:** Q1 2018 was the strongest quarter — 14.0% conversion on 3,343 MQLs. This likely reflects a strong campaign run or improved SDR capacity in early 2018.

---

## 5. Conversion Rate Analysis

### By Acquisition Channel

| Channel | MQLs | Won | Conv Rate | MQL Share | Efficiency |
|---------|------|-----|-----------|-----------|------------|
| Unknown | 1,159 | 193 | **16.65%** | 14.5% | 1.15× |
| Paid Search | 1,586 | 195 | **12.30%** | 19.8% | 0.62× |
| Organic Search | 2,296 | 271 | **11.80%** | 28.7% | 0.41× |
| Direct Traffic | 499 | 56 | **11.22%** | 6.2% | 1.80× |
| Referral | 284 | 24 | **8.45%** | 3.6% | 2.38× |
| Social | 1,350 | 75 | **5.56%** | 16.9% | 0.33× |
| Display | 118 | 6 | **5.08%** | 1.5% | — |
| Other | 215 | 7 | **3.26%** | 2.7% | — |
| Email | 493 | 15 | **3.04%** | 6.2% | 0.49× |

**Efficiency Ratio** = (deal share ÷ MQL share). Values > 1.0 mean the channel delivers proportionally more deals than leads.

> **Critical insight:** Unknown-origin leads convert at 16.65% — the highest of any channel. This is not a real channel — it's traffic we failed to tag. Once attributed, this could significantly change budget allocation decisions.

### By Lead Behaviour Profile (Won Deals Only)

| Profile | Deals | Share | Notes |
|---------|-------|-------|-------|
| Cat | 407 | 48.3% | Cautious, information-seeking |
| Unknown | 177 | 21.0% | Not profiled yet |
| Eagle | 123 | 14.6% | Strategic thinker |
| Wolf | 95 | 11.3% | Competitive, price-focused |
| Shark | 24 | 2.9% | Fast decision maker |

**Cat-type sellers** dominate closed deals. This suggests Olist's content and sales process resonates most with deliberate, research-driven buyers. Eagle and Wolf types together are 26% — suggesting value-based and competitive messaging both work.

### By Lead Type (Digital Maturity)

| Lead Type | Deals | Share |
|-----------|-------|-------|
| Online Medium | 332 | 39.4% |
| Online Big | 126 | 15.0% |
| Industry | 123 | 14.6% |
| Offline | 104 | 12.4% |
| Online Small | 77 | 9.1% |
| Online Beginner | 57 | 6.8% |
| Online Top | 14 | 1.7% |

Mid-tier online sellers (online_medium) form the core of Olist's seller base. Notably, **offline and industry sellers** together account for 27% of deals — suggesting Olist's value proposition for digitally inexperienced businesses is strong and should be highlighted in campaigns targeting traditional retailers.

---

## 6. Drop-off Analysis

### Where Leads Are Lost

```
Total MQL Pool:  8,000 leads
├─ Lost before SDR qualification:  ~4,800 (60.0%) ← BIGGEST LEAK
├─ Lost during sales engagement:   ~1,800 (22.5%)
└─ Lost before close:                ~558  ( 7.0%)
   ──────────────────────────────────────────────
   Won:                               842  (10.5%)
```

### Channel Drop-off (Absolute Volume Lost)

| Channel | Total | Won | Dropped | Drop Rate |
|---------|-------|-----|---------|-----------|
| Organic | 2,296 | 271 | **2,025** | 88.2% |
| Paid Search | 1,586 | 195 | **1,391** | 87.7% |
| Social | 1,350 | 75 | **1,275** | 94.4% |
| Unknown | 1,159 | 193 | 966 | 83.3% |
| Email | 493 | 15 | 478 | **97.0%** |
| Direct | 499 | 56 | 443 | 88.8% |

**Organic and Paid Search lose the most leads in absolute terms** simply because they generate the most volume. However, Social's 94.4% drop rate on 1,350 leads is a strategic concern — it's generating high volume at poor quality.

**Email's 97% drop rate is alarming** given that it's a direct-outreach channel. Email leads should be higher intent than cold organic visitors. This signals a mismatch between email audience targeting and Olist's seller ICP (Ideal Customer Profile).

### Sales Velocity Analysis

| Bucket | Deals | Share |
|--------|-------|-------|
| Fast (< 30 days) | 554 | 65.8% |
| Medium (30–90 days) | 137 | 16.3% |
| Slow (90–180 days) | 83 | 9.9% |
| Very Slow (> 180 days) | 67 | 8.0% |

**Two-thirds of all deals close within 30 days.** This bimodal distribution (fast close vs. long cycle) suggests two types of sellers: those who are ready to join immediately and those who need significant nurturing. Current sales process may be optimized only for the fast group, leaving the slow group to attrition.

---

## 7. Marketing Channel Analysis

### Channel Quadrant Classification

| Quadrant | Channel | Rationale |
|----------|---------|-----------|
| ⭐ **SCALE** — High Vol, High Conv | Organic Search | 2,296 leads at 11.8% — biggest pipeline driver |
| 🚀 **STAR** — Low Vol, High Conv | Direct Traffic, Paid Search | High quality; need volume investment |
| 🔧 **FIX** — High Vol, Low Conv | Social | 1,350 leads at only 5.6% — serious leakage |
| 🔵 **NICHE** — Low Vol, Low Conv | Email, Display, Referral, Other | Either grow or cut |

### Channel Velocity Comparison

| Channel | Avg Days | Interpretation |
|---------|----------|----------------|
| Display | 10.3 days | Very fast — likely high-intent retargeting |
| Direct | 31.1 days | Fast — prospect already knew Olist |
| Referral | 32.5 days | Fast — peer validation pre-qualifies |
| Organic | 50.0 days | Average — research-driven buyers |
| Paid Search | 56.6 days | Slightly slower — possibly competitive shoppers |
| Social | 61.0 days | Slowest to close — lowest intent |

**Social leads take longest to close AND convert at the lowest rate** — making them the worst ROI channel by two measures. Budget reallocation away from Social toward Direct and Referral is strongly recommended.

### Revenue by Channel

| Channel | Total Revenue | Avg per Deal |
|---------|--------------|-------------|
| Organic | BRL 51,426,000 | BRL 189,764 |
| Paid Search | BRL 9,169,000 | BRL 47,021 |
| Unknown | BRL 613,006 | BRL 3,176 |
| Social | BRL 501,000 | BRL 6,680 |
| Direct | BRL 60,000 | BRL 1,071 |

**Organic Search delivers 83% of all declared seller revenue** — overwhelmingly driven by high-value sellers in the Construction Tools segment (declared revenue of BRL 50M+). This outlier significantly skews the average. Excluding Construction Tools, the revenue picture is more balanced.

---

## 8. Business Segment Analysis

### Top 13 Segments — 80% of All Deals

| Segment | Deals | Deal Share | Cumulative % |
|---------|-------|-----------|--------------|
| Home Decor | 105 | 12.5% | 12.5% |
| Health & Beauty | 93 | 11.1% | 23.5% |
| Car Accessories | 77 | 9.1% | 32.7% |
| Household Utilities | 71 | 8.4% | 41.1% |
| Construction Tools | 69 | 8.2% | 49.3% |
| Audio/Video Electronics | 64 | 7.6% | 56.9% |
| Computers | 34 | 4.0% | 60.9% |
| Pet | 30 | 3.6% | 64.5% |
| Food Supplement | 28 | 3.3% | 67.8% |
| Food & Drink | 26 | 3.1% | 70.9% |
| Sports & Leisure | 25 | 3.0% | 73.9% |
| Bed/Bath/Table | 22 | 2.6% | 76.5% |
| Bags & Backpacks | 22 | 2.6% | 79.1% |

**The top 6 segments** (Home Decor through Audio/Video) account for 56.9% of all deals. These verticals should receive dedicated campaign treatment, vertical-specific landing pages, and segment-specific SDR playbooks.

---

## 9. Key Insights

### 🔴 HIGH Priority Insights

1. **Funnel leakage is severe:** 89.5% drop-off means the funnel's primary problem is not lead volume — it's lead quality and conversion process. Throwing more budget at acquisition without fixing the funnel is wasteful.

2. **Unknown channel outperforms all tracked channels (16.65% conv rate):** This is the most important data quality finding. Nearly 1 in 7 leads has no source attribution, yet they convert at the highest rate. Fixing UTM tracking is the single highest-ROI action available.

3. **Email is underdeployed:** Email sends only 493 leads but converts at 3% — which is low for a direct channel. This signals bad list quality or poor email content, not that email is a bad channel. Fixing email targeting could unlock a high-efficiency pipeline.

### 🟡 MEDIUM Priority Insights

4. **Social channel needs a strategic rethink:** 16.9% of MQL budget is directed at Social, which delivers only 5.6% conversion and the slowest close times. The channel may be driving brand awareness (top of funnel) but is not driving seller intent.

5. **Sales cycle is bimodal:** 65.8% of deals close in under 30 days; 18% take 90+ days. There are effectively two buyer types in the funnel, and they likely need different nurturing approaches.

6. **Quarterly trend peaked in Q1 2018:** 14.0% conversion in Q1 2018 vs 11.8% in Q2 2018 suggests some tailwind (campaign, SDR capacity, or market timing) that faded. Identifying what drove Q1 performance is a key research question.

### 🟢 LOW Priority Insights

7. **Cat-profile sellers dominate:** 48% of won deals are 'cat' profile (cautious, research-driven). Sales process and content should be optimized for this buyer type — detailed ROI calculators, case studies, and comparison guides.

8. **Construction Tools is a revenue outlier:** A handful of large construction segment deals appear to have very high declared revenue (BRL 50M+), which inflates channel revenue averages. Segment-specific revenue analysis should exclude this outlier for cleaner benchmarking.

---

## 10. Optimization Recommendations

### 🎯 Priority 1 — Quick Wins (< 30 days)

**REC-1: Fix UTM tracking across all campaigns**
- Problem: 1,099 leads (13.7%) have no channel attribution
- Action: Audit all ad URLs, email links, and social posts for UTM parameters. Create a UTM builder template for the team.
- Target: Unknown origin leads < 2% within 60 days
- Owner: Marketing Operations | Effort: Low (1 week)

**REC-2: Scale email marketing 2× immediately**
- Problem: Email is generating only 493 MQLs despite being a direct-intent channel
- Action: Launch weekly seller nurture sequences; segment by business type (reseller/manufacturer); A/B test subject lines. Focus on warm lists — website visitors, event attendees, trade show contacts.
- Target: Email MQL volume 493 → 1,000+ per cycle
- Owner: Email Marketing | Effort: Low (2 weeks)

**REC-3: Create vertical-specific landing pages for top 3 segments**
- Problem: Generic landing pages don't convert at the rate of the top segments
- Action: Build dedicated pages for Home Decor, Health Beauty, and Car Accessories with segment-specific copy, seller testimonials, and CTAs.
- Target: 5–10% lift in segment-specific conversion
- Owner: Content + Web Team | Effort: Low-Medium (3 weeks)

---

### 📈 Priority 2 — Strategic (30–90 days)

**REC-4: Build a lead scoring model**
- Problem: All 8,000 MQLs receive equal SDR attention — most is wasted on low-intent leads
- Action: Build a logistic regression model using origin, lead_type, business_segment, and time of entry to score each MQL. Route top-quartile scores to senior SDRs.
- Target: 20% more deals from same SDR headcount
- Owner: Data Science + Sales | Effort: Medium (4–6 weeks)

**REC-5: Launch a seller referral program**
- Problem: Referral channel converts at 8.45% and closes in 32 days — but only 284 leads
- Action: Design an incentive structure (commission discount, premium listing, partner badge) for existing sellers who refer new sellers. Track with unique referral codes.
- Target: Referral MQL volume → 500+ per quarter
- Owner: Partnerships + Product | Effort: Medium (6 weeks)

**REC-6: Design a 12-touch SDR nurture sequence for long-cycle leads**
- Problem: 18% of deals take 90+ days — many of these likely go cold with no follow-up
- Action: Build automated CRM sequences: welcome → case study → ROI calculator → demo invite → urgency CTA → check-in. Trigger at 30, 60, and 90-day intervals.
- Target: Reduce median close time from 14 days to maintain fast-close; recover 10% of slow-cycle leads
- Owner: Sales Ops + SDR Team | Effort: Medium (6–8 weeks)

---

### 🔭 Priority 3 — Long-Term (90+ days)

**REC-7: Reallocate paid budget from Social toward Direct + Referral**
- Problem: Social consumes 17% of volume budget at 5.6% conversion — the worst ROI channel
- Action: Run 90-day media mix model. Shift 15% of Social spend toward branded search (drives Direct) and referral incentives.
- Target: Overall funnel conversion 10.5% → 12.5% in 6 months
- Owner: Performance Marketing + Analytics | Effort: Medium-High

**REC-8: Implement CRM behaviour profiling at MQL intake**
- Problem: 21% of closed deals have unknown behaviour profile; SDRs can't personalize
- Action: Add 3 qualifying questions to the MQL form mapping to Cat/Eagle/Wolf/Shark. Train SDRs on profile-specific outreach scripts.
- Target: Profile coverage → 95%+
- Owner: Sales Enablement + Marketing Ops | Effort: High

---

## 11. Power BI Dashboard Design

See `dashboard/powerbi_dashboard_guide.md` for the complete blueprint including:

- **Star schema data model** — FACT_Funnel + 4 dimension tables
- **8 DAX measures** — Conversion Rate, Efficiency Ratio, Revenue per MQL, MoM Growth, etc.
- **6 dashboard pages** — Executive Summary, Channel Analysis, Trends, Segment Deep Dive, Lead Quality, Revenue Intelligence
- **Conditional formatting rules** and color theme (hex codes)
- **Step-by-step deployment guide** for Power BI Service

---

## Appendix: Data Dictionary

| Field | Dataset | Type | Description |
|-------|---------|------|-------------|
| mql_id | Both | string | Unique lead identifier (join key) |
| first_contact_date | Leads | datetime | Date lead first interacted with Olist |
| landing_page_id | Leads | string | Landing page that captured the lead |
| origin | Leads | categorical | Acquisition channel |
| seller_id | Deals | string | Unique seller identifier |
| won_date | Deals | datetime | Date deal was closed |
| business_segment | Deals | categorical | Seller's product category |
| lead_type | Deals | categorical | Digital maturity level of seller |
| lead_behaviour_profile | Deals | categorical | CRM behaviour archetype |
| business_type | Deals | categorical | Reseller or Manufacturer |
| declared_monthly_revenue | Deals | float | Self-reported monthly GMV |
| converted | Master | binary | 1 = won deal, 0 = not converted |
| days_to_close | Master | float | Days from first_contact to won_date |
| channel_group | Master | categorical | Standardized channel grouping |

---

*Report generated by Marketing Analytics Consultant | Olist B2B Funnel Analysis*  
*Python · Pandas · Matplotlib · Seaborn · Power BI*

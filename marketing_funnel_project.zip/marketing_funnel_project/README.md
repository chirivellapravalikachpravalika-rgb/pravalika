# 🎯 Marketing Funnel & Conversion Analysis — Olist B2B

> **Project Type:** Marketing Analytics | Funnel Performance | Conversion Optimization  
> **Dataset:** Olist E-Commerce (Brazil) — MQL & Closed Deals  
> **Analysis Period:** June 2017 – November 2018  
> **Tools:** Python · Pandas · Matplotlib · Seaborn · Power BI

---

## 📋 Project Overview

This project delivers an end-to-end analysis of Olist's B2B marketing funnel — from initial lead acquisition through final deal conversion. It identifies where prospects drop off, which channels deliver the highest-quality leads, and what actions will drive measurable improvement in conversion performance.

### Business Questions Answered
1. What is the overall funnel conversion rate from MQL to closed deal?
2. Which marketing channels generate the most (and best) leads?
3. Where are prospects dropping off in the funnel?
4. Which business segments convert at the highest rates?
5. How has funnel performance trended over time?

---

## 📁 Project Structure

```
marketing_funnel_project/
│
├── data/
│   ├── olist_marketing_qualified_leads_dataset.csv   # 8,000 MQL records
│   └── olist_closed_deals_dataset.csv                # 842 closed deals
│
├── src/
│   ├── 01_data_understanding.py      # Step 1–2: Funnel stages & dataset exploration
│   ├── 02_data_cleaning.py           # Step 3: Cleaning & preprocessing
│   ├── 03_funnel_metrics.py          # Step 4–5: Funnel KPIs & conversion rates
│   ├── 04_dropoff_analysis.py        # Step 6: Drop-off identification
│   ├── 05_channel_analysis.py        # Step 7: Acquisition channel comparison
│   ├── 06_visualizations.py          # Step 8: All charts and plots
│   ├── 07_insights_recommendations.py # Step 9–10: Insights & optimizations
│   └── run_all.py                    # Master runner (executes all steps)
│
├── reports/
│   └── marketing_funnel_report.md    # Full written business report
│
├── visualizations/
│   ├── 01_funnel_overview.png
│   ├── 02_conversion_by_channel.png
│   ├── 03_monthly_trends.png
│   ├── 04_channel_volume_vs_quality.png
│   ├── 05_business_segment_heatmap.png
│   ├── 06_lead_type_conversion.png
│   ├── 07_dropoff_waterfall.png
│   └── 08_revenue_by_channel.png
│
├── dashboard/
│   └── powerbi_dashboard_guide.md    # Power BI design blueprint
│
├── requirements.txt
└── README.md
```

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Full Analysis
```bash
python src/run_all.py
```

### 3. Run Individual Steps
```bash
python src/01_data_understanding.py
python src/02_data_cleaning.py
python src/03_funnel_metrics.py
# ... etc.
```

---

## 📊 Key Findings (Preview)

| Metric | Value |
|--------|-------|
| Total MQLs | 8,000 |
| Closed Deals | 842 |
| **Overall Conversion Rate** | **10.5%** |
| Top Channel (Volume) | Organic Search |
| Top Channel (Conversion) | Direct Traffic |
| Top Business Segment | Home Decor |

---

## 🔑 Top Recommendations

1. **Double down on Direct Traffic** — highest conversion rate of all channels
2. **Fix Unknown/Social funnel leakage** — 1,099 unknown-origin leads are untracked
3. **Prioritize Home Decor & Health Beauty segments** — highest deal volumes
4. **Improve lead profiling** — 21% of closed deals have missing behaviour profile
5. **Launch email nurturing sequences** — email channel is underutilized

---

## 📈 Power BI Dashboard

See `dashboard/powerbi_dashboard_guide.md` for the full DAX measures, data model, and page-by-page layout design.

---

## 🗂️ Data Dictionary

### olist_marketing_qualified_leads_dataset.csv
| Column | Description |
|--------|-------------|
| `mql_id` | Unique identifier for each Marketing Qualified Lead |
| `first_contact_date` | Date the lead first interacted |
| `landing_page_id` | Landing page that captured the lead |
| `origin` | Acquisition channel (organic_search, paid_search, social, etc.) |

### olist_closed_deals_dataset.csv
| Column | Description |
|--------|-------------|
| `mql_id` | Foreign key linking to MQL dataset |
| `seller_id` | Unique seller identifier |
| `won_date` | Date the deal was closed |
| `business_segment` | Product category of the seller |
| `lead_type` | Digital maturity of the lead |
| `lead_behaviour_profile` | CRM behaviour profile (cat/eagle/wolf/shark) |
| `business_type` | Reseller or manufacturer |
| `declared_monthly_revenue` | Self-reported monthly revenue |

---

## 👤 Author

**Marketing Analytics Consultant**  
Olist B2B Funnel Optimization Project  
Analysis Period: 2017–2018

---

*Built with Python · Pandas · Matplotlib · Seaborn · Power BI*

# 📊 Business Report — Global Superstore Sales Performance Analytics

**Prepared by:** Your Name  
**Date:** June 2026  
**Dataset:** Global Superstore (Kaggle) | 51,290 Orders | 2011–2014  

---

## 1. Executive Summary

Global Superstore achieved **$12.64 million in total revenue** and **$1.47 million in profit**
across 7 international markets between 2011 and 2014. Revenue grew consistently each year,
reaching a peak of **$4.30M in 2014** — a 90% increase from 2011.

Despite strong top-line growth, **24.5% of all orders (12,544) are loss-making**,
primarily driven by excessive discounting and underperforming product lines.
This report identifies the root causes and provides six actionable recommendations
to improve profitability.

---

## 2. Business Problem Statement

The Sales Director of Global Superstore requested a comprehensive analysis to answer:

- Are we growing year over year?
- Which markets, categories, and products drive the most profit?
- Why are so many orders loss-making?
- Where should we invest to grow most efficiently?

---

## 3. Dataset Overview

| Property | Value |
|----------|-------|
| Total Records | 51,290 orders |
| Total Columns | 24 (23 after cleaning) |
| Time Period | Jan 2011 — Dec 2014 |
| Markets | US, APAC, EU, Africa, EMEA, LATAM, Canada |
| Product Categories | Technology, Furniture, Office Supplies |
| Customer Segments | Consumer, Corporate, Home Office |

---

## 4. Data Cleaning Summary

| Issue | Action |
|-------|--------|
| Postal Code — 80% missing values | Dropped column entirely |
| Order/Ship Date stored as string text | Converted to Python datetime format |
| No temporal features (Year, Month, Quarter) | Extracted from Order Date |
| Profit Margin not available | Calculated: (Profit ÷ Sales) × 100 |
| Discount stored as decimal (0.14) | Converted to percentage (14%) |
| Inconsistent column naming | Renamed to clean snake_case |
| Duplicate rows | None found — dataset already clean |

**Final cleaned dataset: 51,290 rows × 33 columns**

---

## 5. Key Performance Indicators

| KPI | Value |
|-----|-------|
| Total Sales Revenue | $12,642,501 |
| Total Profit | $1,467,457 |
| Overall Profit Margin | 11.61% |
| Total Unique Orders | 25,035 |
| Unique Customers | 1,590 |
| Average Order Value | $504.99 |
| Loss-Making Orders | 12,544 (24.5%) |

---

## 6. Findings by Analysis Area

### 6.1 Revenue Growth (2011–2014)

| Year | Sales | Profit | YoY Growth |
|------|-------|--------|-----------|
| 2011 | $2.26M | $248.9K | Baseline |
| 2012 | $2.68M | $307.4K | +18.5% |
| 2013 | $3.41M | $406.9K | +27.2% |
| 2014 | $4.30M | $504.2K | +26.3% |

**Finding:** Revenue has grown 90% over 4 years. Q4 is consistently the strongest
quarter across all years, indicating clear seasonal demand patterns.

---

### 6.2 Market Performance

| Market | Sales | Profit | Margin % |
|--------|-------|--------|----------|
| APAC | $3.59M | $436K | 12.2% |
| EU | $2.94M | $373K | 12.7% |
| US | $2.30M | $286K | 12.5% |
| LATAM | $1.91M | $205K | 10.7% |
| Africa | $783K | $89K | 11.4% |
| EMEA | $810K | $76K | 9.4% |
| Canada | $66K | $2K | 2.9% |

**Finding:** APAC and EU are the dominant markets. Canada is severely underperforming
at only 0.5% of total revenue with a critically low 2.9% margin.

---

### 6.3 Product Category Performance

| Category | Sales | Profit | Margin % |
|----------|-------|--------|----------|
| Technology | $4.74M | $663.8K | 14.0% |
| Furniture | $4.11M | $285.2K | 6.9% |
| Office Supplies | $3.79M | $518.5K | 13.7% |

**Finding:** Technology has the highest revenue AND highest profit margin.
Furniture generates high revenue but has the lowest margin — high cost of goods
relative to selling price.

---

### 6.4 Sub-Category Profitability

**Top 5 Profitable Sub-Categories:**
| Sub-Category | Total Profit |
|-------------|-------------|
| Copiers | $258,568 |
| Phones | $216,717 |
| Bookcases | $161,924 |
| Appliances | $141,681 |
| Chairs | $140,396 |

**Loss-Making Sub-Categories:**
| Sub-Category | Total Profit |
|-------------|-------------|
| Tables | −$64,083 ⚠️ |
| Fasteners | $11,525 (near break-even) |
| Labels | $15,011 (very thin margin) |

**Finding:** Tables is the only sub-category generating a net loss.
It should be repriced immediately or phased out.

---

### 6.5 Discount Impact Analysis

- Discount ↔ Profit Correlation: **−0.3165** (meaningful negative relationship)

| Discount Range | Avg Profit per Order |
|---------------|---------------------|
| 0% | +$68 |
| 1–10% | +$55 |
| 11–20% | +$28 |
| 21–30% | −$12 |
| 31–40% | −$38 |
| >40% | −$62 to −$100 |

**Finding:** Every percentage point of discount above 20% erodes profit.
Orders with 0% discount are 6× more profitable than orders with 40%+ discount.

---

### 6.6 Customer Segment Analysis

| Segment | Sales | Profit | Margin % | Avg Order Value |
|---------|-------|--------|----------|----------------|
| Consumer | $6.51M | $749K | 11.51% | $497 |
| Corporate | $3.82M | $441K | 11.54% | $524 |
| Home Office | $2.31M | $277K | 11.99% | $497 |

**Finding:** Consumer is the largest segment by volume. Home Office has the best
profit margin despite smallest volume — potentially the most valuable segment per order.

---

### 6.7 Shipping Analysis

| Ship Mode | Avg Cost | Avg Days | Order Share |
|-----------|---------|---------|------------|
| Same Day | $76.00 | 0 days | 5.2% |
| First Class | $38.00 | 2 days | 15.3% |
| Second Class | $23.00 | 3 days | 19.4% |
| Standard Class | $16.00 | 5 days | 60.1% |

**Finding:** Standard Class is used for 60% of orders at the lowest cost.
Same Day shipping is 4.75× more expensive than Standard Class.

---

## 7. Business Recommendations

### Recommendation 1: Implement Discount Cap Policy
**Problem:** 12,544 orders (24.5%) are loss-making, primarily due to discounts >20%  
**Action:** Set a hard 20% discount cap. Any discount above 20% requires VP-level approval.  
**Expected Outcome:** Reduce loss-making orders by 35–40%; boost overall margin to 13–14%

---

### Recommendation 2: Reprice or Discontinue Tables
**Problem:** Tables is the only sub-category with net negative profit (−$64,083)  
**Action:** Increase Table prices by 15–20%, renegotiate supplier contracts, or phase out  
**Expected Outcome:** Eliminate net loss; save $64K+ annually

---

### Recommendation 3: Expand Technology Product Line
**Problem:** Technology is the best margin category (14%) but may be under-invested  
**Action:** Add new Technology SKUs, focus marketing on APAC and EU for Tech upsell  
**Expected Outcome:** 10–15% revenue uplift in Technology = additional $100–150K profit

---

### Recommendation 4: Targeted Canada Market Growth
**Problem:** Canada generates only $66K (0.5%) of total revenue with 2.9% margin  
**Action:** Assign dedicated Sales Rep, run local campaigns, implement competitive Canada pricing  
**Expected Outcome:** 3× Canada revenue within 2 years

---

### Recommendation 5: Maximize Q4 Seasonality
**Problem:** Q4 is consistently the peak quarter but may not be strategically planned  
**Action:** Pre-build inventory by September, launch promotions in October, set Q4 sales incentives  
**Expected Outcome:** Capture 5–8% additional Q4 revenue

---

### Recommendation 6: VIP Customer Loyalty Program
**Problem:** Top customers are not formally retained with loyalty strategies  
**Action:** Create VIP tier for top 50 customers with dedicated account managers, early access, and exclusive pricing  
**Expected Outcome:** 20% increase in repeat purchase rate; +$200K incremental annual revenue

---

## 8. Conclusion

Global Superstore demonstrates strong growth momentum with 90% revenue increase over 4 years.
However, profitability is being eroded by two key issues: aggressive discounting and
underperforming furniture products. Implementing the six recommendations above can
realistically improve overall profit margin from 11.6% to 14–15%, and reduce loss-making
orders from 24.5% to below 15%.

The APAC and EU markets should remain the primary growth focus, while Canada and EMEA
represent emerging opportunities requiring dedicated investment.

---

*Report generated as part of Data Science & Analytics Internship Project*  
*Dataset Source: Kaggle — Global Superstore | Analysis Tool: Python (Pandas, Matplotlib, Seaborn)*

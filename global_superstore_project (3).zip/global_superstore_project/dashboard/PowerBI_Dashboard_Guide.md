# 📊 Power BI Dashboard Guide — Global Superstore

## How to Build the Dashboard in Power BI Desktop (Free)

### Step 1: Download Power BI Desktop
Go to: https://powerbi.microsoft.com/desktop/ → Download Free

### Step 2: Load the Cleaned Data
- Open Power BI → Get Data → Text/CSV
- Select: `data/global_superstore_cleaned.csv`
- Click Load

### Step 3: Set Data Types in Power Query
- Order_Date → Date
- Sales, Profit, Shipping_Cost → Decimal Number
- Quantity → Whole Number
- All text columns → Text

---

## Dashboard Pages to Build

### PAGE 1 — Executive Overview
| Visual | Type | Fields |
|--------|------|--------|
| Total Sales | KPI Card | Sum of Sales |
| Total Profit | KPI Card | Sum of Profit |
| Profit Margin % | KPI Card | Profit / Sales |
| Total Orders | KPI Card | Count of Order_ID |
| Sales Trend | Line Chart | Order_Date (Month) vs Sales |
| Sales by Market | Bar Chart | Market vs Sales |
| Segment Split | Donut Chart | Segment vs Sales |

### PAGE 2 — Product Analysis
| Visual | Type | Fields |
|--------|------|--------|
| Category Sales vs Profit | Clustered Bar | Category vs Sales & Profit |
| Sub-Category Profit | Bar Chart (sorted) | Sub_Category vs Profit |
| Discount vs Profit | Scatter Plot | Discount % vs Profit |
| Loss Orders Table | Table | Order_ID, Product_Name, Profit (filtered < 0) |

### PAGE 3 — Regional Intelligence
| Visual | Type | Fields |
|--------|------|--------|
| Sales by Country | Map Visual | Country + Sales (bubble size) |
| Top 10 Countries | Bar Chart | Country vs Sales |
| Region Performance | Bar Chart | Region vs Profit |
| Slicers | Slicer | Market, Year, Category |

### PAGE 4 — Customer & Shipping
| Visual | Type | Fields |
|--------|------|--------|
| Top 10 Customers | Bar Chart | Customer_Name vs Sales |
| Segment KPIs | Table | Segment, Sales, Profit, Margin% |
| Ship Mode Cost | Bar Chart | Ship_Mode vs Avg Shipping_Cost |
| Order Priority Mix | Donut | Order_Priority vs Count |

---

## DAX Measures to Create

```dax
Total Sales = SUM(global_superstore_cleaned[Sales])

Total Profit = SUM(global_superstore_cleaned[Profit])

Profit Margin % = DIVIDE([Total Profit], [Total Sales]) * 100

Total Orders = DISTINCTCOUNT(global_superstore_cleaned[Order_ID])

Avg Order Value = DIVIDE([Total Sales], [Total Orders])

Loss Orders = CALCULATE(COUNTROWS(global_superstore_cleaned), 
              global_superstore_cleaned[Is Loss] = TRUE())

YoY Growth % = 
VAR CurrentYear = CALCULATE([Total Sales])
VAR PriorYear = CALCULATE([Total Sales], SAMEPERIODLASTYEAR('Date'[Date]))
RETURN DIVIDE(CurrentYear - PriorYear, PriorYear) * 100
```

---

## Recommended Color Theme
- Primary Blue: #1565C0
- Profit Green: #2E7D32
- Loss Red: #C62828
- Accent Orange: #E65100
- Background: #F8F9FA

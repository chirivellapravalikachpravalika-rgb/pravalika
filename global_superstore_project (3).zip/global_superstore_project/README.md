# 🌍 Global Superstore Sales Performance Analytics

![Python](https://img.shields.io/badge/Python-3.10-blue?logo=python)
![Pandas](https://img.shields.io/badge/Pandas-2.0-150458?logo=pandas)
![Matplotlib](https://img.shields.io/badge/Matplotlib-3.7-orange)
![Seaborn](https://img.shields.io/badge/Seaborn-0.12-teal)
![Status](https://img.shields.io/badge/Status-Completed-brightgreen)
![License](https://img.shields.io/badge/License-MIT-yellow)

---

## 📌 Project Overview

An end-to-end **Data Analytics & Business Intelligence** project analyzing
**51,290 global sales orders** from the Global Superstore dataset (Kaggle) across
**7 international markets** spanning **2011 to 2014**.

This project follows a complete professional data analytics workflow:
Data Cleaning → EDA → Visualization → Business Insights → Recommendations.

---

## 🎯 Business Questions Answered

| # | Question |
|---|----------|
| 1 | Which market and region generates the highest revenue and profit? |
| 2 | Which product category and sub-category is most/least profitable? |
| 3 | What are the yearly and monthly sales trends (2011–2014)? |
| 4 | What is the impact of discounts on profitability? |
| 5 | Which customer segment drives the most revenue? |
| 6 | Who are the Top 10 customers by revenue? |
| 7 | How does shipping mode affect cost and profit? |
| 8 | Which products/sub-categories are loss-makers? |

---

## 📊 Key Findings

| KPI | Value |
|-----|-------|
| 💰 Total Sales Revenue | **$12.64 Million** |
| 📈 Total Profit | **$1.47 Million** |
| 📦 Total Unique Orders | **25,035** |
| 👥 Unique Customers | **1,590** |
| 🎯 Overall Profit Margin | **11.61%** |
| ⚠️ Loss-Making Orders | **12,544 (24.5%)** |

### 🔑 Top Insights
- 📈 **Revenue grew 90%** from $2.26M (2011) to $4.30M (2014)
- 🌏 **APAC is the #1 market** with $3.59M in sales
- 💻 **Technology is the most profitable category** with 14% margin
- 🪑 **Tables sub-category = −$64K net loss** (only loss-making sub-category)
- ⚠️ **Discounts above 40% consistently generate losses** (correlation: −0.32)
- 📅 **Q4 is the peak quarter** every single year — strong seasonality

---

## 🛠️ Tech Stack

| Tool | Purpose |
|------|---------|
| **Python 3.10** | Core programming language |
| **Pandas** | Data manipulation & cleaning |
| **NumPy** | Numerical operations |
| **Matplotlib** | Charts & visualizations |
| **Seaborn** | Statistical visualizations |
| **Jupyter Notebook** | Interactive analysis |
| **Power BI** | Interactive dashboard |

---

## 📂 Project Structure

```
global_superstore_project/
│
├── 📁 data/
│   ├── Global_Superstore2.csv            ← Raw Kaggle dataset
│   └── global_superstore_cleaned.csv     ← Cleaned & enriched dataset
│
├── 📁 notebooks/
│   └── Global_Superstore_Analysis.ipynb  ← Full analysis notebook
│
├── 📁 visuals/
│   ├── chart1_kpi_banner.png             ← KPI Summary Cards
│   ├── chart2_yearly_trend.png           ← Yearly Sales & Profit Trend
│   ├── chart3_monthly_trend.png          ← Monthly Seasonality
│   ├── chart4_market_performance.png     ← Market Performance
│   ├── chart5_category_analysis.png      ← Category & Sub-Category
│   ├── chart6_discount_impact.png        ← Discount vs Profit
│   ├── chart7_segment_analysis.png       ← Customer Segment Analysis
│   ├── chart8_top_customers.png          ← Top 10 Customers
│   ├── chart9_shipping_analysis.png      ← Shipping Mode Analysis
│   └── chart10_quarterly_regional.png    ← Quarterly Heatmap & Regions
│
├── 📁 dashboard/
│   └── PowerBI_Dashboard_Guide.md        ← Power BI setup guide
│
├── 📁 report/
│   └── Business_Report.md               ← Full business report
│
└── README.md                             ← This file
```

---

## 🚀 How to Run This Project

### Step 1: Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/global-superstore-analytics.git
cd global-superstore-analytics
```

### Step 2: Install Dependencies
```bash
pip install pandas numpy matplotlib seaborn jupyter
```

### Step 3: Launch the Notebook
```bash
jupyter notebook notebooks/Global_Superstore_Analysis.ipynb
```

### Step 4: Run All Cells
Click **Kernel → Restart & Run All** to execute the entire analysis.

---

## 📈 Visualizations Preview

### KPI Dashboard
![KPI Banner](visuals/chart1_kpi_banner.png)

### Yearly Sales & Profit Trend
![Yearly Trend](visuals/chart2_yearly_trend.png)

### Monthly Seasonality
![Monthly Trend](visuals/chart3_monthly_trend.png)

### Market Performance
![Market](visuals/chart4_market_performance.png)

### Category & Sub-Category
![Category](visuals/chart5_category_analysis.png)

### Discount Impact Analysis
![Discount](visuals/chart6_discount_impact.png)

### Customer Segment Analysis
![Segment](visuals/chart7_segment_analysis.png)

### Top Customers
![Customers](visuals/chart8_top_customers.png)

### Shipping Analysis
![Shipping](visuals/chart9_shipping_analysis.png)

### Quarterly & Regional Heatmap
![Quarterly](visuals/chart10_quarterly_regional.png)

---

## 💡 Business Recommendations

1. **🚫 Cap discounts at 20%** — Discounts above 20% consistently generate losses
2. **🪑 Reprice or discontinue Tables** — Only sub-category with net negative profit (−$64K)
3. **💻 Expand Technology product line** — Best profit margins, highest ROI
4. **🇨🇦 Grow Canada market** — Currently only 0.5% of revenue; huge untapped potential
5. **📅 Maximize Q4 campaigns** — All years show Q4 peak; prepare inventory by Q3
6. **🏆 Reward top 50 customers** — Loyalty programs can increase repeat purchase by 20%

---

## 📊 Data Cleaning Summary

| Issue Found | Action Taken |
|-------------|-------------|
| Postal Code — 80% missing | Dropped column |
| Order Date stored as text | Converted to datetime |
| Ship Date stored as text | Converted to datetime |
| No Year/Month/Quarter columns | Extracted from Order Date |
| No Profit Margin column | Calculated: (Profit/Sales)×100 |
| Discount stored as 0.14 decimal | Converted to 14% percentage |
| Column names inconsistent | Renamed to snake_case |

---

## 📁 Dataset Information

- **Source:** [Kaggle — Global Superstore Dataset](https://www.kaggle.com/datasets/apoorvaappz/global-super-store-dataset)
- **Records:** 51,290 orders
- **Columns:** 24 (23 after cleaning)
- **Markets:** US, APAC, EU, Africa, EMEA, LATAM, Canada
- **Period:** January 2011 — December 2014

---

## 👤 Author

**Your Name**  
Data Science & Analytics Intern  
📧 your.email@example.com  
🔗 [LinkedIn](https://linkedin.com/in/yourprofile)  
🐙 [GitHub](https://github.com/yourusername)

---

## 📄 License

This project is licensed under the MIT License.  
Dataset is publicly available on Kaggle for educational use.

---

⭐ **If you found this project helpful, please give it a star!** ⭐
